"""
build_final_dataset.py
=====================
Merges three security vulnerability datasets and engineers a rich
feature set ready for ML model training and pipeline creation.

Sources:
  1. final_project/security_dataset.csv   (468 samples, original)
  2. BenchmarkJava-master                 (Java OWASP Benchmark, ~2740 cases)
  3. Juliet C/C++ Test Suite v1.3         (~50k+ C/C++ labelled cases)

Output: final_security_dataset.csv  (all sources combined, features added)
"""

import re, zipfile, io, os, csv, math, sys
from collections import Counter
import pandas as pd
import numpy as np

# ──────────────────────────────────────────────────────────────────────────────
# 1. CONSTANTS & MAPPINGS
# ──────────────────────────────────────────────────────────────────────────────

JULIET_ZIP = "/mnt/user-data/uploads/2017-10-01-juliet-test-suite-for-c-cplusplus-v1-3.zip"
BENCHMARK_ZIP = "/mnt/user-data/uploads/BenchmarkJava-master.zip"
ORIGINAL_CSV = "/home/claude/project/final_project/security_dataset.csv"
OUTPUT_CSV = "/mnt/user-data/outputs/final_security_dataset.csv"

# BenchmarkJava category → (vulnerability_type, cwe_id, severity)
BENCHMARK_CAT_MAP = {
    "pathtraver":   ("Path Traversal",              "CWE-22",  "HIGH"),
    "sqli":         ("SQL Injection",               "CWE-89",  "CRITICAL"),
    "xss":          ("XSS",                         "CWE-79",  "HIGH"),
    "cmdi":         ("Command Injection",            "CWE-78",  "CRITICAL"),
    "crypto":       ("Weak Cryptography",            "CWE-327", "HIGH"),
    "hash":         ("Weak Cryptography",            "CWE-328", "MEDIUM"),
    "weakrand":     ("Insecure Random",              "CWE-338", "MEDIUM"),
    "ldapi":        ("LDAP Injection",               "CWE-90",  "HIGH"),
    "xpathi":       ("XPath Injection",              "CWE-643", "HIGH"),
    "trustbound":   ("Trust Boundary Violation",     "CWE-501", "MEDIUM"),
    "securecookie": ("Insecure Cookie",              "CWE-614", "MEDIUM"),
    "serialize":    ("Unsafe Deserialization",       "CWE-502", "CRITICAL"),
    "headerinjection": ("Header Injection",          "CWE-113", "MEDIUM"),
    "responsesplit":("HTTP Response Splitting",     "CWE-113", "HIGH"),
}

# Juliet CWE folder → (vulnerability_type, severity)
JULIET_CWE_META = {
    "CWE78":  ("Command Injection",          "CRITICAL"),
    "CWE89":  ("SQL Injection",              "CRITICAL"),
    "CWE79":  ("XSS",                        "HIGH"),
    "CWE120": ("Buffer Overflow",            "HIGH"),
    "CWE121": ("Buffer Overflow",            "HIGH"),
    "CWE122": ("Buffer Overflow",            "HIGH"),
    "CWE134": ("Format String",              "HIGH"),
    "CWE190": ("Integer Overflow",           "MEDIUM"),
    "CWE191": ("Integer Underflow",          "MEDIUM"),
    "CWE259": ("Hardcoded Secrets",          "HIGH"),
    "CWE256": ("Hardcoded Secrets",          "HIGH"),
    "CWE321": ("Hardcoded Secrets",          "HIGH"),
    "CWE327": ("Weak Cryptography",          "HIGH"),
    "CWE328": ("Weak Cryptography",          "MEDIUM"),
    "CWE338": ("Insecure Random",            "MEDIUM"),
    "CWE369": ("Divide by Zero",             "MEDIUM"),
    "CWE415": ("Double Free",                "HIGH"),
    "CWE416": ("Use After Free",             "HIGH"),
    "CWE476": ("Null Pointer Dereference",   "MEDIUM"),
    "CWE23":  ("Path Traversal",             "HIGH"),
    "CWE36":  ("Path Traversal",             "HIGH"),
    "CWE401": ("Memory Leak",                "MEDIUM"),
    "CWE90":  ("LDAP Injection",             "HIGH"),
    "CWE789": ("Uncontrolled Memory Alloc",  "HIGH"),
    "CWE114": ("Process Control",            "HIGH"),
    "CWE426": ("Untrusted Search Path",      "HIGH"),
    "CWE400": ("Resource Exhaustion",        "MEDIUM"),
}

SEVERITY_ORDER = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}

# ──────────────────────────────────────────────────────────────────────────────
# 2. FEATURE ENGINEERING
# ──────────────────────────────────────────────────────────────────────────────

def compute_features(code: str, language: str) -> dict:
    """Extract rich static features from a code snippet."""
    if not isinstance(code, str):
        code = ""

    lines = code.splitlines()
    non_blank = [l for l in lines if l.strip()]
    comment_lines = [l for l in lines if _is_comment(l, language)]

    tokens = re.findall(r"\b\w+\b", code)
    token_freq = Counter(tokens)
    unique_tokens = len(token_freq)
    total_tokens = len(tokens)

    # ── Code size metrics ──
    loc = len(lines)
    sloc = len(non_blank)
    code_length = len(code)
    avg_line_length = (code_length / loc) if loc > 0 else 0
    comment_ratio = (len(comment_lines) / loc) if loc > 0 else 0

    # ── Lexical diversity (Type–Token Ratio) ──
    ttr = (unique_tokens / total_tokens) if total_tokens > 0 else 0

    # ── Structural / complexity proxies ──
    num_functions     = _count_functions(code, language)
    num_classes       = _count_classes(code, language)
    num_imports       = _count_imports(code, language)
    nesting_depth     = _max_nesting(code)
    num_conditionals  = len(re.findall(r"\b(if|else|elif|switch|case|ternary|\?)\b", code))
    num_loops         = len(re.findall(r"\b(for|while|do|foreach)\b", code))
    num_try_catch     = len(re.findall(r"\b(try|catch|except|finally)\b", code))
    num_assertions    = len(re.findall(r"\b(assert|assertEquals|assertTrue)\b", code))

    # ── Security-indicator flags ──
    has_user_input     = int(_has_pattern(code, [
        r"request\.", r"req\.", r"argv", r"getParameter", r"input\(",
        r"raw_input", r"Scanner", r"BufferedReader", r"fgets", r"scanf",
        r"HttpServletRequest", r"Cookie", r"getHeader", r"getQueryString"
    ]))
    has_db_query       = int(_has_pattern(code, [
        r"execute\(", r"executeQuery", r"cursor\.", r"PreparedStatement",
        r"Statement", r"sqlite3", r"mysql_query", r"pg_query", r"SELECT\s",
        r"INSERT\s", r"UPDATE\s", r"DELETE\s"
    ]))
    has_exec_call      = int(_has_pattern(code, [
        r"exec\(", r"system\(", r"popen\(", r"subprocess", r"Runtime\.exec",
        r"ProcessBuilder", r"os\.system", r"shell_exec", r"passthru",
        r"eval\(", r"execvp", r"execve"
    ]))
    has_crypto         = int(_has_pattern(code, [
        r"md5\(", r"sha1\(", r"DES\b", r"RC4\b", r"hashlib", r"MessageDigest",
        r"Cipher\.", r"SecretKey", r"AES\b", r"RSA\b", r"ssl\.", r"crypto\."
    ]))
    has_file_ops       = int(_has_pattern(code, [
        r"open\(", r"fopen\(", r"File\(", r"FileInputStream", r"FileOutputStream",
        r"readFile", r"writeFile", r"fs\.", r"path\.join", r"os\.path"
    ]))
    has_network_ops    = int(_has_pattern(code, [
        r"socket\.", r"Socket\(", r"URL\(", r"HttpURLConnection", r"requests\.",
        r"urllib", r"http\.", r"fetch\(", r"XMLHttpRequest", r"curl_exec"
    ]))
    has_dangerous_func = int(_has_pattern(code, [
        r"strcpy\b", r"strcat\b", r"gets\b", r"sprintf\b", r"memcpy\b",
        r"scanf\b", r"printf\b.*%[a-z]", r"malloc\b", r"free\b", r"realloc\b",
        r"pickle\.loads", r"unserialize\(", r"ObjectInputStream",
        r"deserialize", r"yaml\.load\b"
    ]))
    has_hardcoded_secret = int(_has_pattern(code, [
        r'(password|passwd|pwd|secret|api_key|apikey|token)\s*=\s*["\'][^"\']{4,}["\']',
        r'(key|credential)\s*=\s*["\'][^"\']{8,}["\']'
    ]))
    has_string_concat_query = int(_has_pattern(code, [
        r'["\']\s*\+\s*\w',
        r'\w\s*\+\s*["\']',
        r'f".*\{',
        r'%s.*%\s*\(',
    ]))
    has_output_write   = int(_has_pattern(code, [
        r"print\b", r"println\b", r"write\b", r"response\.", r"echo\b",
        r"document\.write", r"innerHTML", r"console\.log"
    ]))
    has_rand           = int(_has_pattern(code, [
        r"rand\b", r"random\b", r"Math\.random", r"Random\(", r"srand\b",
        r"mt_rand", r"rand_r\b"
    ]))
    has_thread_ops     = int(_has_pattern(code, [
        r"Thread\b", r"pthread", r"async\b", r"await\b", r"synchronized",
        r"Lock\b", r"mutex", r"semaphore"
    ]))
    has_reflection     = int(_has_pattern(code, [
        r"Class\.forName", r"getMethod\(", r"invoke\(", r"reflect\.",
        r"eval\b", r"__import__", r"importlib"
    ]))

    # ── Taint-flow proxy: input → dangerous sink same function ──
    taint_proxy = int(has_user_input and (has_db_query or has_exec_call or has_output_write))

    # ── Cyclomatic complexity proxy (branches + 1) ──
    cyclomatic_proxy = num_conditionals + num_loops + 1

    return {
        # Size
        "loc": loc,
        "sloc": sloc,
        "code_length": code_length,
        "avg_line_length": round(avg_line_length, 2),
        "comment_ratio": round(comment_ratio, 3),
        # Lexical
        "num_tokens": total_tokens,
        "num_unique_tokens": unique_tokens,
        "lexical_diversity": round(ttr, 4),
        # Structure
        "num_functions": num_functions,
        "num_classes": num_classes,
        "num_imports": num_imports,
        "nesting_depth": nesting_depth,
        "num_conditionals": num_conditionals,
        "num_loops": num_loops,
        "num_try_catch": num_try_catch,
        "num_assertions": num_assertions,
        "cyclomatic_proxy": cyclomatic_proxy,
        # Security flags
        "has_user_input": has_user_input,
        "has_db_query": has_db_query,
        "has_exec_call": has_exec_call,
        "has_crypto": has_crypto,
        "has_file_ops": has_file_ops,
        "has_network_ops": has_network_ops,
        "has_dangerous_func": has_dangerous_func,
        "has_hardcoded_secret": has_hardcoded_secret,
        "has_string_concat_query": has_string_concat_query,
        "has_output_write": has_output_write,
        "has_rand": has_rand,
        "has_thread_ops": has_thread_ops,
        "has_reflection": has_reflection,
        "taint_flow_proxy": taint_proxy,
    }


def _is_comment(line: str, lang: str) -> bool:
    s = line.strip()
    if lang in ("c", "cpp", "java", "javascript", "go", "rust"):
        return s.startswith("//") or s.startswith("/*") or s.startswith("*")
    if lang == "python":
        return s.startswith("#")
    if lang == "php":
        return s.startswith("//") or s.startswith("#") or s.startswith("/*")
    return s.startswith("//") or s.startswith("#")


def _has_pattern(code: str, patterns: list) -> bool:
    for p in patterns:
        if re.search(p, code, re.IGNORECASE):
            return True
    return False


def _count_functions(code: str, lang: str) -> int:
    if lang == "python":
        return len(re.findall(r"^\s*def\s+\w+", code, re.MULTILINE))
    if lang in ("java", "cpp", "c", "go", "rust", "javascript", "php"):
        return len(re.findall(
            r"(public|private|protected|static|void|int|string|bool|func|fn)?\s+\w+\s*\([^)]*\)\s*[\{:]",
            code))
    return len(re.findall(r"\bfunction\b", code))


def _count_classes(code: str, lang: str) -> int:
    return len(re.findall(r"\bclass\s+\w+", code, re.IGNORECASE))


def _count_imports(code: str, lang: str) -> int:
    if lang == "python":
        return len(re.findall(r"^\s*(import|from)\s+", code, re.MULTILINE))
    if lang in ("java", "cpp", "c"):
        return len(re.findall(r"^\s*(import|#include)\s+", code, re.MULTILINE))
    return len(re.findall(r"^\s*(import|require|use|#include)\s+", code, re.MULTILINE))


def _max_nesting(code: str) -> int:
    depth = max_depth = 0
    for ch in code:
        if ch == "{":
            depth += 1
            max_depth = max(max_depth, depth)
        elif ch == "}":
            depth = max(0, depth - 1)
    # Python / Go style — count indentation levels
    if max_depth == 0:
        for line in code.splitlines():
            indent = len(line) - len(line.lstrip())
            max_depth = max(max_depth, indent // 4)
    return max_depth


def add_label_encodings(df: pd.DataFrame) -> pd.DataFrame:
    """Add numeric/encoded columns for ML readiness."""
    # Severity numeric
    df["severity_numeric"] = df["severity"].map(SEVERITY_ORDER).fillna(1).astype(int)

    # CWE numeric
    df["cwe_numeric"] = df["cwe_id"].str.extract(r"(\d+)").astype(float).fillna(0).astype(int)

    # Language one-hot
    for lang in ["python", "java", "javascript", "cpp", "c", "php", "go", "rust"]:
        df[f"lang_{lang}"] = (df["language"] == lang).astype(int)

    # Vulnerability type encoded (label-encoded sorted by frequency)
    vuln_types = df["vulnerability_type"].value_counts().index.tolist()
    vuln_map = {v: i for i, v in enumerate(vuln_types)}
    df["vuln_type_encoded"] = df["vulnerability_type"].map(vuln_map).fillna(-1).astype(int)

    return df


# ──────────────────────────────────────────────────────────────────────────────
# 3. DATA LOADERS
# ──────────────────────────────────────────────────────────────────────────────

def load_original(csv_path: str) -> pd.DataFrame:
    """Load the original 468-sample dataset exactly as-is, then add features."""
    print(f"  Loading original dataset from {csv_path}...")
    df = pd.read_csv(csv_path)
    df["source"] = "original"
    print(f"  → {len(df)} rows loaded")
    return df


def load_benchmark_java(zip_path: str, max_samples: int = 2000) -> pd.DataFrame:
    """
    Extract Java source files + labels from OWASP BenchmarkJava.
    Labels come from expectedresults-1.2.csv.
    """
    print(f"  Loading BenchmarkJava from {zip_path}...")
    rows = []

    with zipfile.ZipFile(zip_path, "r") as zf:
        # Read expected results
        with zf.open("BenchmarkJava-master/expectedresults-1.2.csv") as f:
            labels = {}
            for line in io.TextIOWrapper(f, encoding="utf-8"):
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                parts = line.split(",")
                if len(parts) >= 4:
                    test_name = parts[0].strip()
                    category  = parts[1].strip()
                    is_vuln   = 1 if parts[2].strip().lower() == "true" else 0
                    cwe_num   = parts[3].strip()
                    labels[test_name] = (category, is_vuln, f"CWE-{cwe_num}")

        # Load source files
        java_files = [
            n for n in zf.namelist()
            if "testcode/BenchmarkTest" in n and n.endswith(".java")
        ]
        print(f"    Found {len(java_files)} Java test files, {len(labels)} labels")

        sampled = java_files[:max_samples]
        for name in sampled:
            test_name = os.path.splitext(os.path.basename(name))[0]
            if test_name not in labels:
                continue
            category, is_vuln, cwe_id = labels[test_name]
            meta = BENCHMARK_CAT_MAP.get(category, ("Unknown", cwe_id, "MEDIUM"))

            try:
                with zf.open(name) as f:
                    code = f.read().decode("utf-8", errors="replace")
            except Exception:
                continue

            rows.append({
                "code":               code,
                "is_vulnerable":      is_vuln,
                "cwe_id":             cwe_id,
                "vulnerability_type": meta[0],
                "severity":           meta[2],
                "language":           "java",
                "source":             "benchmark_java",
            })

    df = pd.DataFrame(rows)
    print(f"  → {len(df)} rows loaded from BenchmarkJava")
    return df


def load_juliet(zip_path: str, max_per_cwe: int = 30) -> pd.DataFrame:
    """
    Extract C/C++ files from Juliet test suite.
    Filename convention: CWExx_...__bad.c  → vulnerable=1
                         CWExx_...__good*.c → vulnerable=0
    Caps to max_per_cwe per CWE to avoid extreme imbalance.
    """
    print(f"  Loading Juliet C/C++ from {zip_path}...")
    rows = []
    cwe_counts: dict = {}

    with zipfile.ZipFile(zip_path, "r") as zf:
        all_files = [
            n for n in zf.namelist()
            if re.search(r"testcases/CWE", n) and (n.endswith(".c") or n.endswith(".cpp"))
        ]
        print(f"    Found {len(all_files)} C/C++ source files")

        for name in all_files:
            # Extract CWE id from folder name
            m = re.search(r"CWE(\d+)_([^/]+)", name)
            if not m:
                continue
            cwe_num = m.group(1)
            cwe_id  = f"CWE-{cwe_num}"
            cwe_key = f"CWE{cwe_num}"

            # Per-CWE cap (balanced)
            counts = cwe_counts.get(cwe_key, {"vuln": 0, "safe": 0})

            # Determine label from filename
            fname = os.path.basename(name).lower()
            if fname.endswith("_bad.c") or fname.endswith("_bad.cpp"):
                is_vuln = 1
                slot = "vuln"
            elif re.search(r"_good", fname):
                is_vuln = 0
                slot = "safe"
            else:
                # Intermediate files (multi-part patterns) — skip
                continue

            if counts.get(slot, 0) >= max_per_cwe:
                continue

            meta = JULIET_CWE_META.get(cwe_key, ("Unknown Vulnerability", "MEDIUM"))
            lang = "cpp" if name.endswith(".cpp") else "c"

            try:
                with zf.open(name) as f:
                    code = f.read().decode("utf-8", errors="replace")
            except Exception:
                continue

            counts[slot] = counts.get(slot, 0) + 1
            cwe_counts[cwe_key] = counts

            rows.append({
                "code":               code,
                "is_vulnerable":      is_vuln,
                "cwe_id":             cwe_id,
                "vulnerability_type": meta[0],
                "severity":           meta[1],
                "language":           lang,
                "source":             "juliet_c_cpp",
            })

    df = pd.DataFrame(rows)
    print(f"  → {len(df)} rows loaded from Juliet")
    return df


# ──────────────────────────────────────────────────────────────────────────────
# 4. MAIN PIPELINE
# ──────────────────────────────────────────────────────────────────────────────

def main():
    print("\n" + "="*60)
    print("  Security Vulnerability Dataset Builder v2.0")
    print("="*60)

    # ── Load all sources ──────────────────────────────────────────
    print("\n[1/5] Loading raw data sources...")
    df_orig      = load_original(ORIGINAL_CSV)
    df_benchmark = load_benchmark_java(BENCHMARK_ZIP, max_samples=2000)
    df_juliet    = load_juliet(JULIET_ZIP, max_per_cwe=30)

    # ── Combine ───────────────────────────────────────────────────
    print("\n[2/5] Combining datasets...")
    df = pd.concat([df_orig, df_benchmark, df_juliet], ignore_index=True)
    print(f"  Total rows before deduplication: {len(df)}")

    # Drop exact code duplicates
    df = df.drop_duplicates(subset=["code"])
    print(f"  Total rows after deduplication:  {len(df)}")

    # ── Feature engineering ───────────────────────────────────────
    print("\n[3/5] Engineering features (this may take a minute)...")
    feature_rows = []
    for i, row in enumerate(df.itertuples(), 1):
        if i % 500 == 0:
            print(f"    Processed {i}/{len(df)}...")
        feats = compute_features(
            getattr(row, "code", ""),
            getattr(row, "language", "python")
        )
        feature_rows.append(feats)

    df_feats = pd.DataFrame(feature_rows)
    df = pd.concat([df.reset_index(drop=True), df_feats], axis=1)
    print(f"  ✓ {len(df_feats.columns)} new feature columns added")

    # ── Label encoding ────────────────────────────────────────────
    print("\n[4/5] Adding label encodings & ML-ready columns...")
    df = add_label_encodings(df)

    # Ensure column ordering: identifiers first, then features
    id_cols = ["source", "language", "vulnerability_type", "cwe_id",
               "severity", "is_vulnerable"]
    feat_cols = sorted([c for c in df.columns
                        if c not in id_cols and c != "code"])
    final_cols = id_cols + feat_cols + ["code"]
    df = df[final_cols]

    # ── Save ──────────────────────────────────────────────────────
    print(f"\n[5/5] Saving final dataset to {OUTPUT_CSV}...")
    os.makedirs(os.path.dirname(OUTPUT_CSV), exist_ok=True)
    df.to_csv(OUTPUT_CSV, index=False)

    # ── Summary ───────────────────────────────────────────────────
    print("\n" + "="*60)
    print("  FINAL DATASET SUMMARY")
    print("="*60)
    print(f"  Total samples    : {len(df):,}")
    print(f"  Feature columns  : {len(df.columns) - 1} (excl. 'code')")
    print(f"\n  Label balance:")
    vc = df["is_vulnerable"].value_counts()
    print(f"    Vulnerable (1)  : {vc.get(1, 0):,} ({100*vc.get(1,0)/len(df):.1f}%)")
    print(f"    Safe (0)        : {vc.get(0, 0):,} ({100*vc.get(0,0)/len(df):.1f}%)")
    print(f"\n  Source breakdown:")
    for src, cnt in df["source"].value_counts().items():
        print(f"    {src:<20} : {cnt:,}")
    print(f"\n  Language breakdown:")
    for lang, cnt in df["language"].value_counts().items():
        print(f"    {lang:<15} : {cnt:,}")
    print(f"\n  Top vulnerability types:")
    for vt, cnt in df["vulnerability_type"].value_counts().head(10).items():
        print(f"    {vt:<40} : {cnt:,}")
    print(f"\n  Severity distribution:")
    for sev, cnt in df["severity"].value_counts().items():
        print(f"    {sev:<10} : {cnt:,}")
    print("\n  Feature columns added:")
    new_feat_cols = [c for c in df.columns if c not in
                     ["source","language","vulnerability_type","cwe_id",
                      "severity","is_vulnerable","code"]]
    for c in new_feat_cols:
        print(f"    • {c}")
    print(f"\n  ✓ Saved: {OUTPUT_CSV}")
    print("="*60 + "\n")

    return df


if __name__ == "__main__":
    main()
