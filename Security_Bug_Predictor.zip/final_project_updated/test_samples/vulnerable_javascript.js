/**
 * Sample Vulnerable JavaScript Code - For Testing Purpose
 * This file contains intentional security vulnerabilities for demonstration
 */

// ========== XSS VULNERABILITIES ==========

function displayUserName(username) {
    // CRITICAL: XSS via innerHTML
    document.getElementById("welcome").innerHTML = "Hello, " + username;
}

function showMessage(message) {
    // CRITICAL: XSS via document.write
    document.write("<div class='message'>" + message + "</div>");
}

function renderTemplate(data) {
    // HIGH: XSS via React dangerouslySetInnerHTML
    return <div dangerouslySetInnerHTML={{ __html: data }} />;
}

function executeUserScript(userCode) {
    // CRITICAL: Code Injection via eval
    eval(userCode);
}

// ========== SQL INJECTION ==========

function getUserData(userId) {
    // CRITICAL: SQL Injection via string concatenation
    const query = "SELECT * FROM users WHERE id = '" + userId + "'";
    db.query(query);
}

function searchProducts(searchTerm) {
    // CRITICAL: SQL Injection via template literal
    const query = `SELECT * FROM products WHERE name LIKE '%${searchTerm}%'`;
    db.execute(query);
}

// ========== COMMAND INJECTION ==========

function backupFile(filename) {
    // CRITICAL: Command Injection
    const exec = require('child_process').exec;
    exec('tar -czf backup.tar.gz ' + filename);
}

function processFile(filepath) {
    // CRITICAL: Shell command injection
    const { exec } = require('child_process');
    exec(`cat ${filepath}`, (error, stdout, stderr) => {
        console.log(stdout);
    });
}

// ========== HARDCODED SECRETS ==========

const API_CONFIG = {
    apiKey: "sk_live_1234567890abcdefghijklmnop",  // HIGH: Hardcoded API key
    apiSecret: "secret_key_xyz_9876543210",        // HIGH: Hardcoded secret
    password: "admin_password_123"                  // HIGH: Hardcoded password
};

function connectToDatabase() {
    // HIGH: Hardcoded credentials
    const dbPassword = "super_secret_db_password";
    return mongoose.connect(`mongodb://admin:${dbPassword}@localhost/mydb`);
}

// ========== AUTHENTICATION BYPASS ==========

function login(username, password) {
    // CRITICAL: Weak authentication
    if (username === "admin" && password === "admin123") {
        return true;
    }
    return false;
}

// ========== INSECURE RANDOM ==========

function generateToken() {
    // MEDIUM: Weak random number generation
    return Math.random().toString(36).substring(2);
}

function createSessionId() {
    // MEDIUM: Predictable session ID
    return Date.now() + "_" + Math.random();
}

// ========== NO INPUT VALIDATION ==========

function processUserInput(input) {
    // HIGH: No input validation
    const result = eval('(' + input + ')');  // Double vulnerability: eval + no validation
    return result;
}

function setUserPreference(key, value) {
    // MEDIUM: No validation on localStorage
    localStorage.setItem(key, value);  // Could be exploited for XSS
}

// ========== INSECURE COMMUNICATION ==========

function sendCredentials(username, password) {
    // HIGH: Sending credentials over HTTP
    fetch('http://api.example.com/login', {
        method: 'POST',
        body: JSON.stringify({ username, password })
    });
}

// ========== PROTOTYPE POLLUTION ==========

function merge(target, source) {
    // HIGH: Prototype pollution vulnerability
    for (let key in source) {
        target[key] = source[key];
    }
    return target;
}

// ========== REGEX DOS ==========

function validateEmail(email) {
    // MEDIUM: ReDoS vulnerability
    const regex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}

// ========== MULTIPLE VULNERABILITIES ==========

function adminPanel(userId, action) {
    /**
     * CRITICAL: Multiple vulnerabilities!
     * - SQL Injection
     * - XSS
     * - Hardcoded admin token
     */
    
    const ADMIN_TOKEN = "super_secret_admin_token_xyz";
    
    // SQL Injection
    const query = `SELECT * FROM users WHERE id = ${userId}`;
    const user = db.query(query);
    
    // XSS
    document.getElementById("userInfo").innerHTML = 
        `User: ${user.name}, Action: ${action}`;
    
    // Information Disclosure
    console.log("Admin token:", ADMIN_TOKEN);
    console.log("Executing admin action:", action);
    
    return user;
}

// ========== EXPORT VULNERABILITIES ==========

module.exports = {
    displayUserName,
    showMessage,
    getUserData,
    searchProducts,
    backupFile,
    API_CONFIG,
    login,
    generateToken,
    sendCredentials
};
