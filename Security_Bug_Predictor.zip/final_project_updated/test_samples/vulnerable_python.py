"""
Sample Vulnerable Python Code - For Testing Purpose
This file contains intentional security vulnerabilities for demonstration
"""

import sqlite3
import os
import subprocess
import pickle
import hashlib

# ========== SQL INJECTION VULNERABILITIES ==========

def get_user_by_id(user_id):
    """CRITICAL: SQL Injection via string concatenation"""
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE id = '" + user_id + "'"
    cursor.execute(query)
    return cursor.fetchone()

def search_products(product_name):
    """CRITICAL: SQL Injection via f-string"""
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()
    query = f"SELECT * FROM products WHERE name = '{product_name}'"
    cursor.execute(query)
    return cursor.fetchall()

# ========== COMMAND INJECTION VULNERABILITIES ==========

def backup_file(filename):
    """CRITICAL: Command Injection via os.system"""
    backup_cmd = "tar -czf backup.tar.gz " + filename
    os.system(backup_cmd)

def process_file(filepath):
    """CRITICAL: Shell Injection via subprocess"""
    subprocess.run(f"cat {filepath}", shell=True)

def execute_user_command(user_input):
    """CRITICAL: Code Injection via eval"""
    result = eval(user_input)
    return result

# ========== HARDCODED SECRETS ==========

def connect_to_database():
    """HIGH: Hardcoded Database Password"""
    DB_PASSWORD = "super_secret_password_123"
    DB_USER = "admin"
    connection_string = f"postgresql://{DB_USER}:{DB_PASSWORD}@localhost/mydb"
    return connection_string

def call_api():
    """HIGH: Hardcoded API Key"""
    API_KEY = "sk_live_1234567890abcdefghijklmnopqrstuvwxyz"
    headers = {"Authorization": f"Bearer {API_KEY}"}
    return headers

SECRET_TOKEN = "my_secret_token_abc123xyz"

# ========== WEAK CRYPTOGRAPHY ==========

def hash_password(password):
    """MEDIUM: Weak MD5 Hash"""
    return hashlib.md5(password.encode()).hexdigest()

def create_session_token(user_id):
    """MEDIUM: Weak SHA1 Hash"""
    token = hashlib.sha1(f"{user_id}".encode()).digest()
    return token

# ========== UNSAFE DESERIALIZATION ==========

def load_user_session(session_data):
    """CRITICAL: Unsafe Pickle Deserialization"""
    user_session = pickle.loads(session_data)
    return user_session

def save_config(config_data):
    """CRITICAL: Unsafe Pickle Serialization"""
    with open('config.pkl', 'wb') as f:
        pickle.dump(config_data, f)

# ========== INFORMATION DISCLOSURE ==========

DEBUG = True  # MEDIUM: Debug mode enabled in production

def login(username, password):
    """MEDIUM: Password in Debug Output"""
    if DEBUG:
        print(f"Login attempt: {username} with password: {password}")
    
    # Actual authentication logic
    return authenticate(username, password)

# ========== PATH TRAVERSAL ==========

def read_user_file(filename):
    """HIGH: Path Traversal Vulnerability"""
    # No validation - user could provide ../../../etc/passwd
    file_path = "/var/app/user_files/" + filename
    with open(file_path, 'r') as f:
        return f.read()

# ========== MULTIPLE VULNERABILITIES ==========

def admin_query(table, column, value):
    """
    CRITICAL: Multiple vulnerabilities in one function!
    - SQL Injection
    - Hardcoded admin password
    - Debug output with sensitive data
    """
    ADMIN_PASSWORD = "admin123"
    
    # SQL Injection
    query = f"SELECT * FROM {table} WHERE {column} = '{value}'"
    conn = sqlite3.connect('admin.db')
    cursor = conn.cursor()
    cursor.execute(query)
    
    # Information disclosure
    print(f"Admin query executed: {query}")
    print(f"Admin password: {ADMIN_PASSWORD}")
    
    return cursor.fetchall()

if __name__ == "__main__":
    # This code is intentionally vulnerable - DO NOT USE IN PRODUCTION
    print("Sample vulnerable code loaded. For testing only!")
