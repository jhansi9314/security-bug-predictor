"""
Security Vulnerability Dataset Generator
Generates realistic labeled code samples for all vulnerability types
and languages supported by the Enhanced Security Bug Prediction System v4.0
"""

import pandas as pd
import random
import itertools

random.seed(42)

# ─────────────────────────────────────────────────────────────────────────────
# PYTHON SAMPLES
# ─────────────────────────────────────────────────────────────────────────────

PYTHON_SAMPLES = [

    # ── SQL Injection ──────────────────────────────────────────────────────

    ("""
import sqlite3

def get_user(username):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE username = '" + username + "'"
    cursor.execute(query)
    return cursor.fetchone()
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "python"),

    ("""
import sqlite3

def search_products(keyword):
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    sql = f"SELECT * FROM products WHERE name LIKE '%{keyword}%'"
    cursor.execute(sql)
    return cursor.fetchall()
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "python"),

    ("""
import sqlite3

def get_user(username):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE username = ?"
    cursor.execute(query, (username,))
    return cursor.fetchone()
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "python"),

    ("""
import sqlite3

def search_products(keyword):
    conn = sqlite3.connect('shop.db')
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM products WHERE name LIKE ?",
        (f'%{keyword}%',)
    )
    return cursor.fetchall()
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "python"),

    ("""
from flask import request
import sqlite3

def login():
    username = request.form['username']
    password = request.form['password']
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    query = "SELECT * FROM users WHERE username='" + username + "' AND password='" + password + "'"
    cursor.execute(query)
    user = cursor.fetchone()
    return user is not None
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "python"),

    ("""
from flask import request
import sqlite3

def login():
    username = request.form['username']
    password = request.form['password']
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    cursor.execute(
        "SELECT * FROM users WHERE username=? AND password=?",
        (username, password)
    )
    user = cursor.fetchone()
    return user is not None
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "python"),

    ("""
import sqlite3
from flask import request

def get_orders():
    user_id = request.args.get('user_id')
    conn = sqlite3.connect('orders.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM orders WHERE user_id = %s" % user_id)
    return cursor.fetchall()
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "python"),

    ("""
import sqlite3
from flask import request

def get_orders():
    user_id = request.args.get('user_id')
    conn = sqlite3.connect('orders.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM orders WHERE user_id = ?", (user_id,))
    return cursor.fetchall()
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "python"),

    # ── Command Injection ──────────────────────────────────────────────────

    ("""
import os
from flask import request

def ping_host():
    host = request.args.get('host')
    result = os.system("ping -c 1 " + host)
    return result
""", 1, "CWE-78", "Command Injection", "CRITICAL", "python"),

    ("""
import subprocess
from flask import request

def convert_file():
    filename = request.form['filename']
    output = subprocess.check_output(
        f"convert {filename} output.pdf", shell=True
    )
    return output
""", 1, "CWE-78", "Command Injection", "CRITICAL", "python"),

    ("""
import subprocess
from flask import request

def ping_host():
    host = request.args.get('host')
    result = subprocess.run(
        ['ping', '-c', '1', host],
        capture_output=True, text=True
    )
    return result.stdout
""", 0, "CWE-78", "Command Injection", "CRITICAL", "python"),

    ("""
import subprocess
from flask import request

def convert_file():
    filename = request.form['filename']
    # Validate filename before use
    if not filename.isalnum():
        return "Invalid filename"
    output = subprocess.run(
        ['convert', filename, 'output.pdf'],
        capture_output=True
    )
    return output.stdout
""", 0, "CWE-78", "Command Injection", "CRITICAL", "python"),

    ("""
import os

def run_report(report_name):
    user_input = input("Enter report name: ")
    os.popen("python reports/" + user_input + ".py")
""", 1, "CWE-78", "Command Injection", "CRITICAL", "python"),

    ("""
import subprocess

def run_report(report_name):
    allowed = ['monthly', 'weekly', 'daily']
    if report_name not in allowed:
        raise ValueError("Invalid report name")
    subprocess.run(['python', f'reports/{report_name}.py'])
""", 0, "CWE-78", "Command Injection", "CRITICAL", "python"),

    # ── Hardcoded Secrets ──────────────────────────────────────────────────

    ("""
import pymysql

def connect_db():
    connection = pymysql.connect(
        host='localhost',
        user='root',
        password='SuperSecret123',
        database='myapp'
    )
    return connection
""", 1, "CWE-798", "Hardcoded Secrets", "HIGH", "python"),

    ("""
import requests

API_KEY = "sk-abc123def456ghi789jkl012mno345"
SECRET_KEY = "mysecretkey_production_2024"

def call_api(endpoint):
    headers = {'Authorization': f'Bearer {API_KEY}'}
    return requests.get(endpoint, headers=headers)
""", 1, "CWE-798", "Hardcoded Secrets", "HIGH", "python"),

    ("""
import os
import pymysql

def connect_db():
    connection = pymysql.connect(
        host=os.environ.get('DB_HOST'),
        user=os.environ.get('DB_USER'),
        password=os.environ.get('DB_PASSWORD'),
        database=os.environ.get('DB_NAME')
    )
    return connection
""", 0, "CWE-798", "Hardcoded Secrets", "HIGH", "python"),

    ("""
import os
import requests

def call_api(endpoint):
    api_key = os.environ.get('API_KEY')
    headers = {'Authorization': f'Bearer {api_key}'}
    return requests.get(endpoint, headers=headers)
""", 0, "CWE-798", "Hardcoded Secrets", "HIGH", "python"),

    ("""
import jwt

def create_token(user_id):
    secret = "hardcoded_jwt_secret_do_not_use"
    token = jwt.encode(
        {'user_id': user_id},
        secret,
        algorithm='HS256'
    )
    return token
""", 1, "CWE-798", "Hardcoded Secrets", "HIGH", "python"),

    ("""
import jwt
import os

def create_token(user_id):
    secret = os.environ.get('JWT_SECRET')
    token = jwt.encode(
        {'user_id': user_id},
        secret,
        algorithm='HS256'
    )
    return token
""", 0, "CWE-798", "Hardcoded Secrets", "HIGH", "python"),

    # ── Weak Cryptography ──────────────────────────────────────────────────

    ("""
import hashlib

def hash_password(password):
    hashed = hashlib.md5(password.encode()).hexdigest()
    return hashed
""", 1, "CWE-327", "Weak Cryptography", "MEDIUM", "python"),

    ("""
import hashlib

def hash_file(filepath):
    with open(filepath, 'rb') as f:
        content = f.read()
    return hashlib.sha1(content).hexdigest()
""", 1, "CWE-327", "Weak Cryptography", "MEDIUM", "python"),

    ("""
import bcrypt

def hash_password(password):
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode(), salt)
    return hashed
""", 0, "CWE-327", "Weak Cryptography", "MEDIUM", "python"),

    ("""
import hashlib

def hash_file(filepath):
    with open(filepath, 'rb') as f:
        content = f.read()
    return hashlib.sha256(content).hexdigest()
""", 0, "CWE-327", "Weak Cryptography", "MEDIUM", "python"),

    ("""
from Crypto.Cipher import DES

def encrypt_data(data, key):
    cipher = DES.new(key, DES.MODE_ECB)
    encrypted = cipher.encrypt(data)
    return encrypted
""", 1, "CWE-327", "Weak Cryptography", "MEDIUM", "python"),

    ("""
from Crypto.Cipher import AES
import os

def encrypt_data(data, key):
    iv = os.urandom(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(data)
    return iv + encrypted
""", 0, "CWE-327", "Weak Cryptography", "MEDIUM", "python"),

    # ── Unsafe Deserialization ─────────────────────────────────────────────

    ("""
import pickle
from flask import request

def load_session():
    session_data = request.cookies.get('session')
    data = pickle.loads(session_data.encode())
    return data
""", 1, "CWE-502", "Unsafe Deserialization", "CRITICAL", "python"),

    ("""
import yaml
from flask import request

def load_config():
    config_data = request.data
    config = yaml.load(config_data)
    return config
""", 1, "CWE-502", "Unsafe Deserialization", "CRITICAL", "python"),

    ("""
import json
from flask import request

def load_session():
    session_data = request.cookies.get('session')
    data = json.loads(session_data)
    return data
""", 0, "CWE-502", "Unsafe Deserialization", "CRITICAL", "python"),

    ("""
import yaml
from flask import request

def load_config():
    config_data = request.data
    config = yaml.load(config_data, Loader=yaml.SafeLoader)
    return config
""", 0, "CWE-502", "Unsafe Deserialization", "CRITICAL", "python"),

    # ── Path Traversal ─────────────────────────────────────────────────────

    ("""
from flask import request, send_file

def download_file():
    filename = request.args.get('file')
    return send_file('/uploads/' + filename)
""", 1, "CWE-22", "Path Traversal", "HIGH", "python"),

    ("""
from flask import request

def read_file():
    path = request.args.get('path')
    with open(path, 'r') as f:
        return f.read()
""", 1, "CWE-22", "Path Traversal", "HIGH", "python"),

    ("""
import os
from flask import request, send_file, abort

def download_file():
    filename = request.args.get('file')
    base_dir = '/uploads'
    filepath = os.path.realpath(os.path.join(base_dir, filename))
    if not filepath.startswith(base_dir):
        abort(403)
    return send_file(filepath)
""", 0, "CWE-22", "Path Traversal", "HIGH", "python"),

    ("""
import os
from flask import request, abort

def read_file():
    filename = request.args.get('file')
    safe_dir = '/var/app/files'
    filepath = os.path.abspath(os.path.join(safe_dir, filename))
    if not filepath.startswith(safe_dir):
        abort(403)
    with open(filepath, 'r') as f:
        return f.read()
""", 0, "CWE-22", "Path Traversal", "HIGH", "python"),

    # ── SSRF ──────────────────────────────────────────────────────────────

    ("""
import requests
from flask import request

def fetch_url():
    url = request.args.get('url')
    response = requests.get(url)
    return response.text
""", 1, "CWE-918", "SSRF", "HIGH", "python"),

    ("""
import urllib.request
from flask import request

def fetch_resource():
    url = request.form.get('resource_url')
    data = urllib.request.urlopen(url).read()
    return data
""", 1, "CWE-918", "SSRF", "HIGH", "python"),

    ("""
import requests
from flask import request
from urllib.parse import urlparse

ALLOWED_DOMAINS = ['api.trusted.com', 'data.safe.org']

def fetch_url():
    url = request.args.get('url')
    parsed = urlparse(url)
    if parsed.netloc not in ALLOWED_DOMAINS:
        return "Domain not allowed", 403
    response = requests.get(url, timeout=5)
    return response.text
""", 0, "CWE-918", "SSRF", "HIGH", "python"),

    # ── Insecure Random ────────────────────────────────────────────────────

    ("""
import random
import string

def generate_token():
    chars = string.ascii_letters + string.digits
    token = ''.join(random.choice(chars) for _ in range(32))
    return token
""", 1, "CWE-338", "Insecure Random", "MEDIUM", "python"),

    ("""
import random

def generate_otp():
    return str(random.randint(100000, 999999))
""", 1, "CWE-338", "Insecure Random", "MEDIUM", "python"),

    ("""
import secrets
import string

def generate_token():
    chars = string.ascii_letters + string.digits
    token = ''.join(secrets.choice(chars) for _ in range(32))
    return token
""", 0, "CWE-338", "Insecure Random", "MEDIUM", "python"),

    ("""
import secrets

def generate_otp():
    return str(secrets.randbelow(900000) + 100000)
""", 0, "CWE-338", "Insecure Random", "MEDIUM", "python"),
]

# ─────────────────────────────────────────────────────────────────────────────
# JAVASCRIPT SAMPLES
# ─────────────────────────────────────────────────────────────────────────────

JAVASCRIPT_SAMPLES = [

    # ── XSS ───────────────────────────────────────────────────────────────

    ("""
function displayMessage(req, res) {
    const message = req.query.message;
    res.send('<div>' + message + '</div>');
}
""", 1, "CWE-79", "XSS", "HIGH", "javascript"),

    ("""
function updateProfile(userData) {
    document.getElementById('username').innerHTML = userData.name;
    document.getElementById('bio').innerHTML = userData.bio;
}
""", 1, "CWE-79", "XSS", "HIGH", "javascript"),

    ("""
const DOMPurify = require('dompurify');

function displayMessage(req, res) {
    const message = DOMPurify.sanitize(req.query.message);
    res.send('<div>' + message + '</div>');
}
""", 0, "CWE-79", "XSS", "HIGH", "javascript"),

    ("""
function updateProfile(userData) {
    document.getElementById('username').textContent = userData.name;
    document.getElementById('bio').textContent = userData.bio;
}
""", 0, "CWE-79", "XSS", "HIGH", "javascript"),

    ("""
function renderComment(comment) {
    const div = document.createElement('div');
    div.innerHTML = comment.text;
    document.body.appendChild(div);
}
""", 1, "CWE-79", "XSS", "HIGH", "javascript"),

    ("""
function renderComment(comment) {
    const div = document.createElement('div');
    div.textContent = comment.text;
    document.body.appendChild(div);
}
""", 0, "CWE-79", "XSS", "HIGH", "javascript"),

    # ── SQL Injection ──────────────────────────────────────────────────────

    ("""
const mysql = require('mysql');

function getUser(req, res) {
    const username = req.body.username;
    const query = "SELECT * FROM users WHERE username = '" + username + "'";
    connection.query(query, (err, results) => {
        res.json(results);
    });
}
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "javascript"),

    ("""
const knex = require('knex');

function searchUsers(req, res) {
    const name = req.query.name;
    knex.raw("SELECT * FROM users WHERE name = '" + name + "'")
        .then(results => res.json(results));
}
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "javascript"),

    ("""
const mysql = require('mysql');

function getUser(req, res) {
    const username = req.body.username;
    const query = "SELECT * FROM users WHERE username = ?";
    connection.query(query, [username], (err, results) => {
        res.json(results);
    });
}
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "javascript"),

    # ── Command Injection ──────────────────────────────────────────────────

    ("""
const { exec } = require('child_process');

function convertFile(req, res) {
    const filename = req.body.filename;
    exec('convert ' + filename + ' output.pdf', (err, stdout) => {
        res.send(stdout);
    });
}
""", 1, "CWE-78", "Command Injection", "CRITICAL", "javascript"),

    ("""
const { execFile } = require('child_process');

function convertFile(req, res) {
    const filename = req.body.filename;
    if (!/^[a-zA-Z0-9_.-]+$/.test(filename)) {
        return res.status(400).send('Invalid filename');
    }
    execFile('convert', [filename, 'output.pdf'], (err, stdout) => {
        res.send(stdout);
    });
}
""", 0, "CWE-78", "Command Injection", "CRITICAL", "javascript"),

    # ── Hardcoded Secrets ──────────────────────────────────────────────────

    ("""
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'mysecretkey123456789';
const DB_PASSWORD = 'admin_password_2024';

function createToken(userId) {
    return jwt.sign({ userId }, SECRET_KEY, { expiresIn: '1h' });
}
""", 1, "CWE-798", "Hardcoded Secrets", "HIGH", "javascript"),

    ("""
const jwt = require('jsonwebtoken');

function createToken(userId) {
    const secretKey = process.env.JWT_SECRET;
    return jwt.sign({ userId }, secretKey, { expiresIn: '1h' });
}
""", 0, "CWE-798", "Hardcoded Secrets", "HIGH", "javascript"),

    # ── Prototype Pollution ────────────────────────────────────────────────

    ("""
function mergeObjects(target, source) {
    for (let key in source) {
        target[key] = source[key];
    }
    return target;
}
""", 1, "CWE-1321", "Prototype Pollution", "HIGH", "javascript"),

    ("""
function mergeObjects(target, source) {
    for (let key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
            if (key !== '__proto__' && key !== 'constructor') {
                target[key] = source[key];
            }
        }
    }
    return target;
}
""", 0, "CWE-1321", "Prototype Pollution", "HIGH", "javascript"),

    ("""
const express = require('express');
const app = express();

app.post('/update', (req, res) => {
    const user = {};
    Object.assign(user, req.body);
    res.json(user);
});
""", 1, "CWE-1321", "Prototype Pollution", "HIGH", "javascript"),

    # ── Insecure Random ────────────────────────────────────────────────────

    ("""
function generateToken() {
    return Math.random().toString(36).substring(2);
}

function generateSessionId() {
    return Math.floor(Math.random() * 1000000).toString();
}
""", 1, "CWE-338", "Insecure Random", "MEDIUM", "javascript"),

    ("""
const crypto = require('crypto');

function generateToken() {
    return crypto.randomBytes(32).toString('hex');
}

function generateSessionId() {
    return crypto.randomUUID();
}
""", 0, "CWE-338", "Insecure Random", "MEDIUM", "javascript"),

    # ── Open Redirect ──────────────────────────────────────────────────────

    ("""
function handleLogin(req, res) {
    const redirectUrl = req.query.next;
    if (isLoggedIn(req)) {
        res.redirect(redirectUrl);
    }
}
""", 1, "CWE-601", "Open Redirect", "HIGH", "javascript"),

    ("""
function handleLogin(req, res) {
    const redirectUrl = req.query.next;
    const allowedPaths = ['/dashboard', '/profile', '/home'];
    if (isLoggedIn(req) && allowedPaths.includes(redirectUrl)) {
        res.redirect(redirectUrl);
    } else {
        res.redirect('/dashboard');
    }
}
""", 0, "CWE-601", "Open Redirect", "HIGH", "javascript"),
]

# ─────────────────────────────────────────────────────────────────────────────
# JAVA SAMPLES
# ─────────────────────────────────────────────────────────────────────────────

JAVA_SAMPLES = [

    # ── SQL Injection ──────────────────────────────────────────────────────

    ("""
import java.sql.*;

public class UserDAO {
    public User getUser(String username) throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(
            "SELECT * FROM users WHERE username = '" + username + "'"
        );
        return mapUser(rs);
    }
}
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "java"),

    ("""
import java.sql.*;

public class UserDAO {
    public User getUser(String username) throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL);
        PreparedStatement stmt = conn.prepareStatement(
            "SELECT * FROM users WHERE username = ?"
        );
        stmt.setString(1, username);
        ResultSet rs = stmt.executeQuery();
        return mapUser(rs);
    }
}
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "java"),

    ("""
import javax.persistence.*;

public class ProductDAO {
    public List<Product> searchProducts(String keyword) {
        EntityManager em = factory.createEntityManager();
        Query query = em.createQuery(
            "SELECT p FROM Product p WHERE p.name LIKE '%" + keyword + "%'"
        );
        return query.getResultList();
    }
}
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "java"),

    ("""
import javax.persistence.*;

public class ProductDAO {
    public List<Product> searchProducts(String keyword) {
        EntityManager em = factory.createEntityManager();
        TypedQuery<Product> query = em.createQuery(
            "SELECT p FROM Product p WHERE p.name LIKE :keyword",
            Product.class
        );
        query.setParameter("keyword", "%" + keyword + "%");
        return query.getResultList();
    }
}
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "java"),

    # ── Command Injection ──────────────────────────────────────────────────

    ("""
import java.io.*;

public class FileProcessor {
    public String processFile(String filename) throws IOException {
        Runtime rt = Runtime.getRuntime();
        Process proc = rt.exec("convert " + filename + " output.pdf");
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(proc.getInputStream())
        );
        return reader.readLine();
    }
}
""", 1, "CWE-78", "Command Injection", "CRITICAL", "java"),

    ("""
import java.io.*;

public class FileProcessor {
    public String processFile(String filename) throws IOException {
        if (!filename.matches("[a-zA-Z0-9._-]+")) {
            throw new IllegalArgumentException("Invalid filename");
        }
        ProcessBuilder pb = new ProcessBuilder("convert", filename, "output.pdf");
        Process proc = pb.start();
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(proc.getInputStream())
        );
        return reader.readLine();
    }
}
""", 0, "CWE-78", "Command Injection", "CRITICAL", "java"),

    # ── Unsafe Deserialization ─────────────────────────────────────────────

    ("""
import java.io.*;

public class SessionManager {
    public Object loadSession(byte[] data) throws Exception {
        ByteArrayInputStream bis = new ByteArrayInputStream(data);
        ObjectInputStream ois = new ObjectInputStream(bis);
        return ois.readObject();
    }
}
""", 1, "CWE-502", "Unsafe Deserialization", "CRITICAL", "java"),

    ("""
import com.fasterxml.jackson.databind.ObjectMapper;

public class SessionManager {
    public SessionData loadSession(String jsonData) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.readValue(jsonData, SessionData.class);
    }
}
""", 0, "CWE-502", "Unsafe Deserialization", "CRITICAL", "java"),

    # ── Sensitive Information Disclosure ──────────────────────────────────

    ("""
public class AuthController {
    public boolean login(String username, String password) {
        try {
            return authService.authenticate(username, password);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Login failed for: " + password);
            return false;
        }
    }
}
""", 1, "CWE-200", "Sensitive Information Disclosure", "HIGH", "java"),

    ("""
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuthController {
    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    public boolean login(String username, String password) {
        try {
            return authService.authenticate(username, password);
        } catch (Exception e) {
            log.error("Login failed for user: {}", username);
            return false;
        }
    }
}
""", 0, "CWE-200", "Sensitive Information Disclosure", "HIGH", "java"),

    # ── Weak Cryptography ──────────────────────────────────────────────────

    ("""
import java.security.MessageDigest;

public class PasswordUtil {
    public String hashPassword(String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] hash = md.digest(password.getBytes());
        return bytesToHex(hash);
    }
}
""", 1, "CWE-327", "Weak Cryptography", "MEDIUM", "java"),

    ("""
import org.mindrot.jbcrypt.BCrypt;

public class PasswordUtil {
    public String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt(12));
    }

    public boolean checkPassword(String password, String hashed) {
        return BCrypt.checkpw(password, hashed);
    }
}
""", 0, "CWE-327", "Weak Cryptography", "MEDIUM", "java"),

    # ── Hardcoded Secrets ──────────────────────────────────────────────────

    ("""
public class DatabaseConfig {
    private static final String DB_URL = "jdbc:mysql://localhost/mydb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "admin123456";
    private static final String SECRET_KEY = "mysecretkey_prod";
}
""", 1, "CWE-798", "Hardcoded Secrets", "HIGH", "java"),

    ("""
public class DatabaseConfig {
    private static final String DB_URL = System.getenv("DB_URL");
    private static final String DB_USER = System.getenv("DB_USER");
    private static final String DB_PASSWORD = System.getenv("DB_PASSWORD");
    private static final String SECRET_KEY = System.getenv("SECRET_KEY");
}
""", 0, "CWE-798", "Hardcoded Secrets", "HIGH", "java"),

    # ── SSRF ──────────────────────────────────────────────────────────────

    ("""
import java.net.*;
import javax.servlet.http.*;

public class ProxyController {
    public String fetchUrl(HttpServletRequest request) throws Exception {
        String url = request.getParameter("url");
        URL targetUrl = new URL(url);
        HttpURLConnection conn = (HttpURLConnection) targetUrl.openConnection();
        return readResponse(conn);
    }
}
""", 1, "CWE-918", "SSRF", "HIGH", "java"),

    ("""
import java.net.*;
import javax.servlet.http.*;

public class ProxyController {
    private static final List<String> ALLOWED_HOSTS =
        Arrays.asList("api.trusted.com", "data.internal.com");

    public String fetchUrl(HttpServletRequest request) throws Exception {
        String url = request.getParameter("url");
        URL targetUrl = new URL(url);
        if (!ALLOWED_HOSTS.contains(targetUrl.getHost())) {
            throw new SecurityException("Host not allowed");
        }
        HttpURLConnection conn = (HttpURLConnection) targetUrl.openConnection();
        return readResponse(conn);
    }
}
""", 0, "CWE-918", "SSRF", "HIGH", "java"),
]

# ─────────────────────────────────────────────────────────────────────────────
# C/C++ SAMPLES
# ─────────────────────────────────────────────────────────────────────────────

C_SAMPLES = [

    # ── Buffer Overflow ────────────────────────────────────────────────────

    ("""
#include <string.h>
#include <stdio.h>

void copy_input(char *input) {
    char buffer[64];
    strcpy(buffer, input);
    printf("Copied: %s\\n", buffer);
}
""", 1, "CWE-120", "Buffer Overflow", "CRITICAL", "cpp"),

    ("""
#include <string.h>
#include <stdio.h>

void copy_input(char *input) {
    char buffer[64];
    strncpy(buffer, input, sizeof(buffer) - 1);
    buffer[sizeof(buffer) - 1] = '\\0';
    printf("Copied: %s\\n", buffer);
}
""", 0, "CWE-120", "Buffer Overflow", "CRITICAL", "cpp"),

    ("""
#include <stdio.h>

void read_input() {
    char buffer[256];
    gets(buffer);
    printf("Input: %s\\n", buffer);
}
""", 1, "CWE-120", "Buffer Overflow", "CRITICAL", "cpp"),

    ("""
#include <stdio.h>

void read_input() {
    char buffer[256];
    fgets(buffer, sizeof(buffer), stdin);
    printf("Input: %s\\n", buffer);
}
""", 0, "CWE-120", "Buffer Overflow", "CRITICAL", "cpp"),

    ("""
#include <stdio.h>
#include <string.h>

void process_name(char *name) {
    char result[100];
    sprintf(result, "Hello, %s!", name);
    printf("%s\\n", result);
}
""", 1, "CWE-120", "Buffer Overflow", "CRITICAL", "cpp"),

    ("""
#include <stdio.h>
#include <string.h>

void process_name(char *name) {
    char result[100];
    snprintf(result, sizeof(result), "Hello, %s!", name);
    printf("%s\\n", result);
}
""", 0, "CWE-120", "Buffer Overflow", "CRITICAL", "cpp"),

    # ── Format String ──────────────────────────────────────────────────────

    ("""
#include <stdio.h>

void log_message(char *message) {
    printf(message);
}

void display_error(char *error) {
    fprintf(stderr, error);
}
""", 1, "CWE-134", "Format String", "CRITICAL", "cpp"),

    ("""
#include <stdio.h>

void log_message(char *message) {
    printf("%s", message);
}

void display_error(char *error) {
    fprintf(stderr, "%s", error);
}
""", 0, "CWE-134", "Format String", "CRITICAL", "cpp"),

    # ── Integer Overflow ───────────────────────────────────────────────────

    ("""
#include <stdlib.h>

void* allocate_buffer(int count, int size) {
    int total = count * size;
    void* buf = malloc(total);
    return buf;
}
""", 1, "CWE-190", "Integer Overflow", "MEDIUM", "cpp"),

    ("""
#include <stdlib.h>
#include <stdint.h>
#include <limits.h>

void* allocate_buffer(int count, int size) {
    if (count > 0 && size > INT_MAX / count) {
        return NULL;
    }
    int total = count * size;
    void* buf = malloc(total);
    return buf;
}
""", 0, "CWE-190", "Integer Overflow", "MEDIUM", "cpp"),

    # ── Command Injection ──────────────────────────────────────────────────

    ("""
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

void run_command(char *filename) {
    char cmd[256];
    sprintf(cmd, "process %s", filename);
    system(cmd);
}
""", 1, "CWE-78", "Command Injection", "CRITICAL", "cpp"),

    ("""
#include <unistd.h>

void run_command(char *filename) {
    char *args[] = {"process", filename, NULL};
    execvp(args[0], args);
}
""", 0, "CWE-78", "Command Injection", "CRITICAL", "cpp"),

    # ── Null Pointer Dereference ───────────────────────────────────────────

    ("""
#include <stdlib.h>
#include <string.h>

void process_data(int size) {
    char *buffer = (char*)malloc(size);
    memset(buffer, 0, size);
    buffer[0] = 'A';
}
""", 1, "CWE-476", "Null Pointer Dereference", "MEDIUM", "cpp"),

    ("""
#include <stdlib.h>
#include <string.h>

void process_data(int size) {
    char *buffer = (char*)malloc(size);
    if (buffer == NULL) {
        return;
    }
    memset(buffer, 0, size);
    buffer[0] = 'A';
    free(buffer);
}
""", 0, "CWE-476", "Null Pointer Dereference", "MEDIUM", "cpp"),
]

# ─────────────────────────────────────────────────────────────────────────────
# PHP SAMPLES
# ─────────────────────────────────────────────────────────────────────────────

PHP_SAMPLES = [

    # ── SQL Injection ──────────────────────────────────────────────────────

    ("""
<?php
function getUser($username) {
    $conn = mysqli_connect("localhost", "root", "password", "mydb");
    $query = "SELECT * FROM users WHERE username = '" . $username . "'";
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($result);
}
?>
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "php"),

    ("""
<?php
function getUser($username) {
    $conn = new PDO("mysql:host=localhost;dbname=mydb", "root", "password");
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->execute([':username' => $username]);
    return $stmt->fetch();
}
?>
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "php"),

    # ── XSS ───────────────────────────────────────────────────────────────

    ("""
<?php
$name = $_GET['name'];
echo "<h1>Hello, " . $name . "</h1>";
?>
""", 1, "CWE-79", "XSS", "HIGH", "php"),

    ("""
<?php
$name = htmlspecialchars($_GET['name'], ENT_QUOTES, 'UTF-8');
echo "<h1>Hello, " . $name . "</h1>";
?>
""", 0, "CWE-79", "XSS", "HIGH", "php"),

    ("""
<?php
$search = $_POST['search'];
echo "Results for: " . $search;
?>
""", 1, "CWE-79", "XSS", "HIGH", "php"),

    ("""
<?php
$search = filter_input(INPUT_POST, 'search', FILTER_SANITIZE_SPECIAL_CHARS);
echo "Results for: " . $search;
?>
""", 0, "CWE-79", "XSS", "HIGH", "php"),

    # ── Command Injection ──────────────────────────────────────────────────

    ("""
<?php
$file = $_POST['filename'];
$output = shell_exec("convert " . $file . " output.pdf");
echo $output;
?>
""", 1, "CWE-78", "Command Injection", "CRITICAL", "php"),

    ("""
<?php
$file = escapeshellarg($_POST['filename']);
$output = shell_exec("convert " . $file . " output.pdf");
echo $output;
?>
""", 0, "CWE-78", "Command Injection", "CRITICAL", "php"),

    # ── File Inclusion ─────────────────────────────────────────────────────

    ("""
<?php
$page = $_GET['page'];
include($page . '.php');
?>
""", 1, "CWE-98", "File Inclusion", "CRITICAL", "php"),

    ("""
<?php
$allowed_pages = ['home', 'about', 'contact'];
$page = $_GET['page'];
if (!in_array($page, $allowed_pages)) {
    die("Invalid page");
}
include($page . '.php');
?>
""", 0, "CWE-98", "File Inclusion", "CRITICAL", "php"),

    # ── Hardcoded Secrets ──────────────────────────────────────────────────

    ("""
<?php
$db_host = 'localhost';
$db_user = 'root';
$db_password = 'SuperSecret123!';
$api_key = 'abc123def456ghi789';

$conn = mysqli_connect($db_host, $db_user, $db_password);
?>
""", 1, "CWE-798", "Hardcoded Secrets", "HIGH", "php"),

    ("""
<?php
$db_host = getenv('DB_HOST');
$db_user = getenv('DB_USER');
$db_password = getenv('DB_PASSWORD');
$api_key = getenv('API_KEY');

$conn = mysqli_connect($db_host, $db_user, $db_password);
?>
""", 0, "CWE-798", "Hardcoded Secrets", "HIGH", "php"),
]

# ─────────────────────────────────────────────────────────────────────────────
# GO SAMPLES
# ─────────────────────────────────────────────────────────────────────────────

GO_SAMPLES = [

    # ── SQL Injection ──────────────────────────────────────────────────────

    ("""
package main

import (
    "database/sql"
    "fmt"
    "net/http"
)

func getUser(db *sql.DB, r *http.Request) {
    username := r.URL.Query().Get("username")
    query := fmt.Sprintf("SELECT * FROM users WHERE username = '%s'", username)
    rows, _ := db.Query(query)
    defer rows.Close()
}
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "go"),

    ("""
package main

import (
    "database/sql"
    "net/http"
)

func getUser(db *sql.DB, r *http.Request) {
    username := r.URL.Query().Get("username")
    rows, _ := db.Query("SELECT * FROM users WHERE username = ?", username)
    defer rows.Close()
}
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "go"),

    # ── Command Injection ──────────────────────────────────────────────────

    ("""
package main

import (
    "net/http"
    "os/exec"
)

func convertFile(w http.ResponseWriter, r *http.Request) {
    filename := r.FormValue("filename")
    cmd := exec.Command("sh", "-c", "convert "+filename+" output.pdf")
    cmd.Run()
}
""", 1, "CWE-78", "Command Injection", "CRITICAL", "go"),

    ("""
package main

import (
    "net/http"
    "os/exec"
    "regexp"
)

func convertFile(w http.ResponseWriter, r *http.Request) {
    filename := r.FormValue("filename")
    matched, _ := regexp.MatchString("^[a-zA-Z0-9._-]+$", filename)
    if !matched {
        http.Error(w, "Invalid filename", http.StatusBadRequest)
        return
    }
    cmd := exec.Command("convert", filename, "output.pdf")
    cmd.Run()
}
""", 0, "CWE-78", "Command Injection", "CRITICAL", "go"),

    # ── SSRF ──────────────────────────────────────────────────────────────

    ("""
package main

import (
    "io/ioutil"
    "net/http"
)

func fetchUrl(w http.ResponseWriter, r *http.Request) {
    url := r.URL.Query().Get("url")
    resp, _ := http.Get(url)
    body, _ := ioutil.ReadAll(resp.Body)
    w.Write(body)
}
""", 1, "CWE-918", "SSRF", "HIGH", "go"),

    ("""
package main

import (
    "errors"
    "io/ioutil"
    "net/http"
    "net/url"
)

var allowedHosts = map[string]bool{
    "api.trusted.com": true,
    "data.safe.org":   true,
}

func fetchUrl(w http.ResponseWriter, r *http.Request) {
    rawUrl := r.URL.Query().Get("url")
    parsed, err := url.Parse(rawUrl)
    if err != nil || !allowedHosts[parsed.Host] {
        http.Error(w, "URL not allowed", http.StatusForbidden)
        return
    }
    resp, _ := http.Get(rawUrl)
    body, _ := ioutil.ReadAll(resp.Body)
    w.Write(body)
}
""", 0, "CWE-918", "SSRF", "HIGH", "go"),

    # ── Hardcoded Secrets ──────────────────────────────────────────────────

    ("""
package main

import "database/sql"

const (
    dbPassword = "SuperSecret123"
    apiKey     = "sk-prod-abc123def456ghi789"
    jwtSecret  = "my_jwt_secret_key"
)

func connectDB() *sql.DB {
    db, _ := sql.Open("mysql", "root:"+dbPassword+"@/mydb")
    return db
}
""", 1, "CWE-798", "Hardcoded Secrets", "HIGH", "go"),

    ("""
package main

import (
    "database/sql"
    "os"
)

func connectDB() *sql.DB {
    dbPassword := os.Getenv("DB_PASSWORD")
    db, _ := sql.Open("mysql", "root:"+dbPassword+"@/mydb")
    return db
}
""", 0, "CWE-798", "Hardcoded Secrets", "HIGH", "go"),
]

# ─────────────────────────────────────────────────────────────────────────────
# RUST SAMPLES
# ─────────────────────────────────────────────────────────────────────────────

RUST_SAMPLES = [

    # ── SQL Injection ──────────────────────────────────────────────────────

    ("""
use rusqlite::Connection;

fn get_user(conn: &Connection, username: &str) {
    let query = format!(
        "SELECT * FROM users WHERE username = '{}'", username
    );
    conn.execute(&query, []).unwrap();
}
""", 1, "CWE-89", "SQL Injection", "CRITICAL", "rust"),

    ("""
use rusqlite::{Connection, params};

fn get_user(conn: &Connection, username: &str) {
    conn.execute(
        "SELECT * FROM users WHERE username = ?1",
        params![username]
    ).unwrap();
}
""", 0, "CWE-89", "SQL Injection", "CRITICAL", "rust"),

    # ── Command Injection ──────────────────────────────────────────────────

    ("""
use std::process::Command;

fn convert_file(filename: &str) {
    let output = Command::new("sh")
        .arg("-c")
        .arg(format!("convert {} output.pdf", filename))
        .output()
        .unwrap();
}
""", 1, "CWE-78", "Command Injection", "CRITICAL", "rust"),

    ("""
use std::process::Command;

fn convert_file(filename: &str) {
    let output = Command::new("convert")
        .arg(filename)
        .arg("output.pdf")
        .output()
        .unwrap();
}
""", 0, "CWE-78", "Command Injection", "CRITICAL", "rust"),

    # ── Hardcoded Secrets ──────────────────────────────────────────────────

    ("""
const DB_PASSWORD: &str = "SuperSecret123";
const API_KEY: &str = "sk-prod-abc123def456ghi789jkl";
const JWT_SECRET: &str = "my_production_jwt_secret";

fn main() {
    println!("Connecting with password: {}", DB_PASSWORD);
}
""", 1, "CWE-798", "Hardcoded Secrets", "HIGH", "rust"),

    ("""
use std::env;

fn main() {
    let db_password = env::var("DB_PASSWORD").expect("DB_PASSWORD not set");
    let api_key = env::var("API_KEY").expect("API_KEY not set");
    println!("Connected");
}
""", 0, "CWE-798", "Hardcoded Secrets", "HIGH", "rust"),
]

# ─────────────────────────────────────────────────────────────────────────────
# BUILD THE DATASET
# ─────────────────────────────────────────────────────────────────────────────

def build_dataset():
    all_samples = (
        PYTHON_SAMPLES +
        JAVASCRIPT_SAMPLES +
        JAVA_SAMPLES +
        C_SAMPLES +
        PHP_SAMPLES +
        GO_SAMPLES +
        RUST_SAMPLES
    )

    rows = []
    for sample in all_samples:
        code, label, cwe, vuln_type, severity, language = sample
        rows.append({
            'code'             : code.strip(),
            'is_vulnerable'    : label,
            'cwe_id'           : cwe,
            'vulnerability_type': vuln_type,
            'severity'         : severity,
            'language'         : language,
        })

    df = pd.DataFrame(rows)

    # Augment dataset — create slight variations to increase size
    augmented = []
    for _, row in df.iterrows():
        # Add comment variations
        for i in range(3):
            new_row = row.copy()
            comment = f"# version {i+1}\n" if row['language'] == 'python' else f"// version {i+1}\n"
            new_row['code'] = comment + row['code']
            augmented.append(new_row)

    augmented_df = pd.DataFrame(augmented)
    final_df = pd.concat([df, augmented_df], ignore_index=True)
    final_df = final_df.drop_duplicates(subset=['code']).reset_index(drop=True)

    return final_df


if __name__ == '__main__':
    df = build_dataset()
    df.to_csv('security_dataset.csv', index=False)

    print("="*55)
    print("DATASET GENERATED")
    print("="*55)
    print(f"Total samples      : {len(df)}")
    print(f"Vulnerable (1)     : {df['is_vulnerable'].sum()}")
    print(f"Safe (0)           : {(df['is_vulnerable']==0).sum()}")
    print(f"\nBy language:")
    print(df['language'].value_counts().to_string())
    print(f"\nBy vulnerability type:")
    print(df['vulnerability_type'].value_counts().to_string())
    print(f"\nBy severity:")
    print(df['severity'].value_counts().to_string())
    print("="*55)
    print("Saved: security_dataset.csv")
