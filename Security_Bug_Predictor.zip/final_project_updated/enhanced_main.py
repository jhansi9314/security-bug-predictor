import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
import subprocess
import json
import os
import tempfile
import threading
import sqlite3
from datetime import datetime
import re
from pathlib import Path
import pickle
import numpy as np
import joblib
from collections import defaultdict

# ML imports
try:
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    from sklearn.multiclass import OneVsRestClassifier
    ML_AVAILABLE = True
except ImportError:
    ML_AVAILABLE = False
    print("⚠️  ML libraries not available. Install scikit-learn for ML predictions.")

# ─────────────────────────────────────────────────────────────────────────────
# CWE MAPPING DATABASE
# ─────────────────────────────────────────────────────────────────────────────
CWE_MAP = {
    "SQL Injection":               {"id": "CWE-89",  "name": "Improper Neutralization of SQL Commands",        "url": "https://cwe.mitre.org/data/definitions/89.html"},
    "Command Injection":           {"id": "CWE-78",  "name": "Improper Neutralization of OS Commands",         "url": "https://cwe.mitre.org/data/definitions/78.html"},
    "XSS":                         {"id": "CWE-79",  "name": "Cross-site Scripting",                           "url": "https://cwe.mitre.org/data/definitions/79.html"},
    "Buffer Overflow":             {"id": "CWE-120", "name": "Buffer Copy without Checking Size of Input",     "url": "https://cwe.mitre.org/data/definitions/120.html"},
    "Unsafe Deserialization":      {"id": "CWE-502", "name": "Deserialization of Untrusted Data",              "url": "https://cwe.mitre.org/data/definitions/502.html"},
    "Hardcoded Secrets":           {"id": "CWE-798", "name": "Use of Hard-coded Credentials",                  "url": "https://cwe.mitre.org/data/definitions/798.html"},
    "Weak Cryptography":           {"id": "CWE-327", "name": "Use of a Broken or Risky Cryptographic Algorithm","url": "https://cwe.mitre.org/data/definitions/327.html"},
    "Path Traversal":              {"id": "CWE-22",  "name": "Improper Limitation of a Pathname",              "url": "https://cwe.mitre.org/data/definitions/22.html"},
    "File Inclusion":              {"id": "CWE-98",  "name": "Improper Control of Filename for Include",       "url": "https://cwe.mitre.org/data/definitions/98.html"},
    "Sensitive Information Disclosure": {"id": "CWE-200", "name": "Exposure of Sensitive Information",        "url": "https://cwe.mitre.org/data/definitions/200.html"},
    "Insecure Random":             {"id": "CWE-338", "name": "Use of Cryptographically Weak PRNG",             "url": "https://cwe.mitre.org/data/definitions/338.html"},
    "Prototype Pollution":         {"id": "CWE-1321","name": "Improperly Controlled Modification of Object",   "url": "https://cwe.mitre.org/data/definitions/1321.html"},
    "ReDoS":                       {"id": "CWE-1333","name": "Inefficient Regular Expression Complexity",      "url": "https://cwe.mitre.org/data/definitions/1333.html"},
    "Open Redirect":               {"id": "CWE-601", "name": "URL Redirection to Untrusted Site",              "url": "https://cwe.mitre.org/data/definitions/601.html"},
    "SSRF":                        {"id": "CWE-918", "name": "Server-Side Request Forgery",                    "url": "https://cwe.mitre.org/data/definitions/918.html"},
    "Format String":               {"id": "CWE-134", "name": "Use of Externally-Controlled Format String",    "url": "https://cwe.mitre.org/data/definitions/134.html"},
    "Integer Overflow":            {"id": "CWE-190", "name": "Integer Overflow or Wraparound",                 "url": "https://cwe.mitre.org/data/definitions/190.html"},
    "Use After Free":              {"id": "CWE-416", "name": "Use After Free",                                  "url": "https://cwe.mitre.org/data/definitions/416.html"},
    "Race Condition":              {"id": "CWE-362", "name": "Concurrent Execution Using Shared Resource",     "url": "https://cwe.mitre.org/data/definitions/362.html"},
    "Null Pointer Dereference":    {"id": "CWE-476", "name": "NULL Pointer Dereference",                       "url": "https://cwe.mitre.org/data/definitions/476.html"},
}

REMEDIATION_MAP = {
    "SQL Injection":    "Use parameterized queries or prepared statements. Never concatenate user input into SQL.",
    "Command Injection":"Use subprocess with argument lists (no shell=True). Validate and sanitize all inputs.",
    "XSS":              "Sanitize all user input. Use textContent instead of innerHTML. Apply Content Security Policy (CSP).",
    "Buffer Overflow":  "Replace unsafe functions (strcpy, gets) with safe alternatives (strncpy, fgets). Use bounds checking.",
    "Unsafe Deserialization": "Use JSON or XML instead of pickle/yaml.load. If pickle is needed, verify data integrity with HMAC.",
    "Hardcoded Secrets":"Move credentials to environment variables or a secrets manager (e.g., HashiCorp Vault, AWS Secrets Manager).",
    "Weak Cryptography":"Replace MD5/SHA1 with SHA-256 or bcrypt/argon2 for passwords. Use AES-256 for encryption.",
    "Path Traversal":   "Use os.path.abspath() and validate paths are within expected directories. Reject '../' sequences.",
    "File Inclusion":   "Validate and whitelist file paths. Never use user input directly in include/require statements.",
    "Sensitive Information Disclosure": "Remove debug output from production. Use structured logging that filters sensitive data.",
    "Insecure Random":  "Use secrets module (Python) or crypto.getRandomValues() (JS) for security-sensitive randomness.",
    "Prototype Pollution": "Use Object.create(null) or validate keys before merging. Use hasOwnProperty() checks.",
    "ReDoS":            "Rewrite regex to be non-backtracking. Use timeout wrappers for user-supplied patterns.",
    "SSRF":             "Validate and whitelist URLs. Restrict outbound network access. Reject private IP ranges.",
    "Format String":    "Never pass user input as format string argument. Use explicit format string like printf('%s', userInput).",
}

# ─────────────────────────────────────────────────────────────────────────────
# TAINT ANALYSIS ENGINE
# ─────────────────────────────────────────────────────────────────────────────
class TaintAnalysisEngine:
    """
    Tracks data flow from user-controlled sources → dangerous sinks.
    SOURCE → FLOW → SINK  ==  taint path = real vulnerability
    """

    SOURCES = {
        "python": [
            r'\binput\s*\(',
            r'request\.(args|form|data|json|files|cookies|headers|values|get|post)\b',
            r'sys\.argv\b',
            r'os\.environ\b',
            r'os\.getenv\s*\(',
            r'open\s*\([^)]*["\']r',
            r'fileinput\.',
            r'stdin\.read',
            r'socket\.recv',
        ],
        "javascript": [
            r'req\.(body|query|params|headers|cookies)\b',
            r'request\.(body|query|params)\b',
            r'document\.(URL|location|referrer|cookie)\b',
            r'window\.location\b',
            r'location\.(search|hash|href)\b',
            r'decodeURI(Component)?\s*\(',
            r'localStorage\.getItem\s*\(',
            r'sessionStorage\.getItem\s*\(',
            r'URLSearchParams\b',
        ],
        "java": [
            r'request\.(getParameter|getHeader|getCookies|getQueryString|getInputStream)\s*\(',
            r'System\.in\b',
            r'Scanner\s*\(\s*System\.in\)',
            r'BufferedReader\s*\(\s*new\s+InputStreamReader',
            r'getenv\s*\(',
        ],
        "cpp": [
            r'\bcin\b\s*>>',
            r'\bscanf\s*\(',
            r'\bfgets?\s*\(',
            r'\bgetline\s*\(',
            r'\bgetenv\s*\(',
            r'\bargv\b',
        ],
        "php": [
            r'\$_(GET|POST|REQUEST|COOKIE|SERVER|FILES|SESSION)\b',
            r'file_get_contents\s*\(\s*["\']php://input',
            r'getallheaders\s*\(',
        ],
        "go": [
            r'r\.(URL\.Query|FormValue|Header\.Get|Cookie)\s*\(',
            r'os\.Args\b',
            r'os\.Getenv\s*\(',
        ],
        "rust": [
            r'std::env::args\s*\(',
            r'std::env::var\s*\(',
            r'std::io::stdin\b',
        ],
    }

    SINKS = {
        "python": {
            "Command Injection":  [r'\bos\.system\s*\(', r'\bsubprocess\.(run|call|check_output|Popen)\s*\(', r'\beval\s*\(', r'\bexec\s*\('],
            "SQL Injection":      [r'\.execute\s*\(', r'cursor\.execute\s*\(', r'\.executemany\s*\('],
            "Path Traversal":     [r'\bopen\s*\(', r'os\.(path\.)?(join|abspath|realpath)', r'pathlib\.Path\s*\('],
            "SSRF":               [r'urllib\.request\.urlopen\s*\(', r'requests\.(get|post|put|delete|head)\s*\(', r'httpx\.(get|post)\s*\('],
            "Unsafe Deserialization": [r'pickle\.loads?\s*\(', r'yaml\.load\s*\(', r'marshal\.loads\s*\('],
        },
        "javascript": {
            "XSS":               [r'\.innerHTML\s*=', r'document\.write\s*\(', r'\.outerHTML\s*=', r'eval\s*\(', r'setTimeout\s*\([^,)]*,', r'setInterval\s*\([^,)]*,'],
            "Command Injection": [r'exec\s*\(', r'child_process\.\w+\s*\(', r'execSync\s*\(', r'spawnSync\s*\('],
            "SQL Injection":     [r'db\.(query|execute)\s*\(', r'connection\.(query|execute)\s*\(', r'pool\.(query|execute)\s*\('],
            "Open Redirect":     [r'window\.location\s*=', r'location\.replace\s*\(', r'location\.assign\s*\(', r'res\.redirect\s*\('],
        },
        "java": {
            "Command Injection": [r'Runtime\.getRuntime\(\)\.exec\s*\(', r'ProcessBuilder\s*\(', r'new\s+ProcessBuilder'],
            "SQL Injection":     [r'(Statement|PreparedStatement)\s*\.(execute|executeQuery|executeUpdate)\s*\(', r'createQuery\s*\(', r'createNativeQuery\s*\('],
            "Path Traversal":    [r'new\s+File(Reader|Writer|InputStream|OutputStream)\s*\(', r'Files\.(read|write|copy|move)\s*\(', r'new\s+File\s*\('],
            "SSRF":              [r'new\s+URL\s*\(', r'openConnection\s*\(', r'HttpClient\.(get|post)\s*\('],
        },
        "cpp": {
            "Command Injection": [r'\bsystem\s*\(', r'\bpopen\s*\(', r'\bexeclp?\s*\(', r'\bexecvp?\s*\('],
            "Buffer Overflow":   [r'\bstrcpy\s*\(', r'\bstrcat\s*\(', r'\bsprintf\s*\(', r'\bgets\s*\(', r'\bsscanf\s*\('],
            "SQL Injection":     [r'mysql_query\s*\(', r'sqlite3_exec\s*\('],
            "Format String":     [r'\bprintf\s*\(\s*\w+\s*\)', r'\bfprintf\s*\(\s*\w+\s*,\s*\w+\s*\)'],
        },
        "php": {
            "Command Injection": [r'\b(exec|shell_exec|system|passthru|popen|proc_open)\s*\('],
            "SQL Injection":     [r'mysql(i)?_(query|real_query)\s*\(', r'->query\s*\(', r'->prepare\s*\('],
            "XSS":               [r'\becho\b', r'\bprint\b', r'\bprintf\s*\(', r'<\?='],
            "File Inclusion":    [r'\b(include|require|include_once|require_once)\s*[\(\s]'],
            "Path Traversal":    [r'file_(get|put)_contents\s*\(', r'fopen\s*\(', r'readfile\s*\('],
        },
        "go": {
            "Command Injection": [r'exec\.Command\s*\(', r'exec\.CommandContext\s*\('],
            "SQL Injection":     [r'db\.(Query|Exec|QueryRow)\s*\(', r'\.(Query|Exec)\s*\('],
            "SSRF":              [r'http\.(Get|Post|Do)\s*\(', r'client\.(Get|Post|Do)\s*\('],
        },
        "rust": {
            "Command Injection": [r'Command::new\s*\(', r'\.spawn\s*\(\)', r'\.output\s*\(\)'],
            "SQL Injection":     [r'\.execute\s*\(', r'\.query\s*\(', r'\.query_one\s*\('],
        },
    }

    def analyze(self, code, language):
        """
        Simple line-proximity taint analysis.
        Returns list of taint findings with flow explanation.
        """
        findings = []
        lines = code.split('\n')
        lang = language.lower()

        sources_patterns = self.SOURCES.get(lang, [])
        sinks_map = self.SINKS.get(lang, {})

        # Find all source lines
        source_lines = []
        for i, line in enumerate(lines, 1):
            for pat in sources_patterns:
                if re.search(pat, line, re.IGNORECASE):
                    # Extract variable name assigned from source
                    var_match = re.match(r'\s*(\w+)\s*=', line)
                    var_name = var_match.group(1) if var_match else None
                    source_lines.append({
                        'line': i,
                        'code': line.strip(),
                        'var': var_name,
                        'pattern': pat
                    })

        # For each sink, check if user-controlled variable flows into it
        for sink_type, sink_patterns in sinks_map.items():
            for i, line in enumerate(lines, 1):
                for spat in sink_patterns:
                    if re.search(spat, line, re.IGNORECASE):
                        # Look for any source variable referenced in this sink line (within 30 lines)
                        for src in source_lines:
                            distance = abs(i - src['line'])
                            if distance > 30:
                                continue
                            # Check if the source var appears in the sink line
                            var_in_sink = src['var'] and src['var'] in line
                            close_enough = distance <= 5  # nearby = suspicious even without var tracking
                            if var_in_sink or close_enough:
                                findings.append({
                                    'type': sink_type,
                                    'taint_flow': True,
                                    'source_line': src['line'],
                                    'source_code': src['code'],
                                    'sink_line': i,
                                    'sink_code': line.strip(),
                                    'explanation': (
                                        f"User-controlled data from line {src['line']} "
                                        f"({src['code'][:60]}…) flows into {sink_type.lower()} sink "
                                        f"at line {i} ({line.strip()[:60]}…)"
                                    ),
                                    'severity': self._sink_severity(sink_type),
                                    'source': 'Taint Analysis',
                                    'var': src['var'],
                                    'distance': distance
                                })
                                break  # one finding per sink line per type
        return findings

    def _sink_severity(self, sink_type):
        critical = {"SQL Injection", "Command Injection", "Unsafe Deserialization", "Buffer Overflow"}
        high = {"XSS", "Path Traversal", "SSRF", "Open Redirect", "Format String", "File Inclusion"}
        if sink_type in critical:
            return "CRITICAL"
        elif sink_type in high:
            return "HIGH"
        return "MEDIUM"


# ─────────────────────────────────────────────────────────────────────────────
# DEVELOPER METRICS
# ─────────────────────────────────────────────────────────────────────────────
class DeveloperMetrics:
    def __init__(self):
        self.developer_history = defaultdict(lambda: {
            'total_commits': 0, 'bug_commits': 0,
            'components_touched': set(), 'total_files': 0
        })

    def calculate_developer_focus(self, developer_id):
        dev_data = self.developer_history[developer_id]
        if dev_data['total_commits'] == 0:
            return 0.5
        focus = 1.0 - (len(dev_data['components_touched']) / max(dev_data['total_commits'], 1))
        return max(0.0, min(1.0, focus))

    def calculate_bug_ratio(self, developer_id):
        dev_data = self.developer_history[developer_id]
        if dev_data['total_commits'] == 0:
            return 0.0
        return dev_data['bug_commits'] / dev_data['total_commits']

    def update_history(self, developer_id, component, has_bug=False):
        dev_data = self.developer_history[developer_id]
        dev_data['total_commits'] += 1
        dev_data['components_touched'].add(component)
        if has_bug:
            dev_data['bug_commits'] += 1


# ─────────────────────────────────────────────────────────────────────────────
# ML SECURITY PREDICTOR  (now classifies vuln TYPE, not just risk label)
# ─────────────────────────────────────────────────────────────────────────────
class MLSecurityPredictor:
    """
    ML predictor v5.0 — Pipeline-based (scaler embedded in each model).
    Trained on final_security_dataset.csv (330k+ samples, 42 features, 8 languages).

    Pipeline files produced by train_model.py:
      models/randomforest_pipeline.pkl
      models/gradientboosting_pipeline.pkl
      models/training_summary_v2.json

    Inference uses a 60/40 RF+GB ensemble.
    Falls back to a lightweight random-data fallback when model files are absent.
    """

    VULN_CLASSES = [
        "SQL Injection", "Command Injection", "XSS", "Hardcoded Secrets",
        "Weak Cryptography", "Unsafe Deserialization", "Buffer Overflow",
        "Path Traversal", "SSRF", "Insecure Random",
    ]

    # 42 feature columns matching final_security_dataset.csv
    FEATURE_COLS = [
        "loc", "sloc", "code_length", "avg_line_length", "comment_ratio",
        "num_tokens", "num_unique_tokens", "lexical_diversity",
        "num_functions", "num_classes", "num_imports", "nesting_depth",
        "num_conditionals", "num_loops", "num_try_catch", "num_assertions",
        "cyclomatic_proxy",
        "has_user_input", "has_db_query", "has_exec_call", "has_crypto",
        "has_file_ops", "has_network_ops", "has_dangerous_func",
        "has_hardcoded_secret", "has_string_concat_query", "has_output_write",
        "has_rand", "has_thread_ops", "has_reflection", "taint_flow_proxy",
        "cwe_numeric", "severity_numeric", "vuln_type_encoded",
        "lang_python", "lang_java", "lang_javascript", "lang_cpp",
        "lang_c", "lang_php", "lang_go", "lang_rust",
    ]

    def __init__(self):
        self.rf_pipeline   = None
        self.gb_pipeline   = None
        self.is_trained    = False
        self.feature_names = self.FEATURE_COLS   # alias for compatibility

    # ── Feature extraction ────────────────────────────────────────────────────

    def extract_features(self, code: str, file_path: str,
                         developer_metrics, language: str = 'python') -> np.ndarray:
        """
        Extract 42 features using the same patterns as build_final_dataset.py
        so training and inference features are perfectly aligned.
        Returns shape (1, 42).
        """
        def _has(patterns):
            return int(any(re.search(p, code) for p in patterns))

        lines_     = code.splitlines()
        non_blank  = [l for l in lines_ if l.strip()]
        tokens     = re.findall(r"\b\w+\b", code)
        total_tok  = len(tokens)
        unique_tok = len(set(tokens))

        # Size
        loc             = len(lines_)
        sloc            = len(non_blank)
        code_length     = len(code)
        avg_line_length = (code_length / loc) if loc > 0 else 0
        comment_lines   = [l for l in lines_ if l.strip().startswith(('/', '*', '#'))]
        comment_ratio   = len(comment_lines) / loc if loc > 0 else 0
        # Lexical
        num_tokens        = total_tok
        num_unique_tokens = unique_tok
        lexical_diversity = (unique_tok / total_tok) if total_tok > 0 else 0
        # Structure
        num_functions    = len(re.findall(r'\b(def |function |func )\s*\w+\s*\(', code, re.I))
        num_classes      = len(re.findall(r'\bclass\s+\w+', code))
        num_imports      = len(re.findall(r'^\s*(import |from .* import |#include )', code, re.M | re.I))
        max_depth = 0
        for line in lines_:
            if line.strip():
                indent = (len(line) - len(line.lstrip())) // 4
                max_depth = max(max_depth, indent)
        nesting_depth    = max_depth
        num_conditionals = len(re.findall(r'\b(if|else|elif|switch|case)\b', code))
        num_loops        = len(re.findall(r'\b(for|while|do|foreach)\b', code))
        num_try_catch    = len(re.findall(r'\b(try|catch|except|finally)\b', code))
        num_assertions   = len(re.findall(r'\b(assert|assertEquals|assertTrue)\b', code))
        cyclomatic_proxy = num_conditionals + num_loops + 1
        # Security flags — patterns match build_final_dataset.py exactly
        has_user_input  = _has([r"request\.", r"req\.", r"argv", r"getParameter",
            r"input\(", r"raw_input", r"Scanner", r"BufferedReader",
            r"fgets", r"scanf", r"HttpServletRequest", r"Cookie",
            r"getHeader", r"getQueryString"])
        has_db_query = _has([r"execute\(", r"executeQuery", r"cursor\.",
            r"PreparedStatement", r"Statement", r"sqlite3",
            r"mysql_query", r"pg_query", r"SELECT\s",
            r"INSERT\s", r"UPDATE\s", r"DELETE\s"])
        has_exec_call = _has([r"exec\(", r"system\(", r"popen\(", r"subprocess",
            r"Runtime\.exec", r"ProcessBuilder", r"os\.system",
            r"shell_exec", r"passthru", r"eval\(", r"execvp", r"execve"])
        has_crypto = _has([r"md5\(", r"sha1\(", r"DES\b", r"RC4\b",
            r"hashlib", r"MessageDigest", r"Cipher\.", r"SecretKey",
            r"AES\b", r"RSA\b", r"ssl\.", r"crypto\."])
        has_file_ops = _has([r"open\(", r"fopen\(", r"File\(", r"FileInputStream",
            r"FileOutputStream", r"readFile", r"writeFile",
            r"fs\.", r"path\.join", r"os\.path"])
        has_network_ops = _has([r"socket\.", r"Socket\(", r"URL\(",
            r"HttpURLConnection", r"requests\.", r"urllib",
            r"http\.", r"fetch\(", r"XMLHttpRequest", r"curl_exec"])
        has_dangerous_func = _has([r"strcpy\b", r"strcat\b", r"gets\b",
            r"sprintf\b", r"memcpy\b", r"scanf\b", r"malloc\b",
            r"free\b", r"realloc\b", r"pickle\.loads",
            r"unserialize\(", r"ObjectInputStream",
            r"deserialize", r"yaml\.load\b"])
        has_hardcoded_secret = _has([
            r"(?i)(password|passwd|secret|api_key|token)\s*=\s*[^\s=].{4,}",
        ])
        has_string_concat_query = _has([
            r"[\"\']+\s*\+\s*\w", r"\w\s*\+\s*[\"\']+", r"f\".*\{",
        ])
        has_output_write = _has([r"print\b", r"println\b", r"write\b",
            r"response\.", r"echo\b", r"document\.write",
            r"innerHTML", r"console\.log"])
        has_rand = _has([r"rand\b", r"random\b", r"Math\.random",
            r"Random\(", r"srand\b", r"mt_rand", r"rand_r\b"])
        has_thread_ops = _has([r"Thread\b", r"pthread", r"async\b",
            r"await\b", r"synchronized", r"Lock\b", r"mutex", r"semaphore"])
        has_reflection = _has([r"Class\.forName", r"getMethod\(", r"invoke\(",
            r"reflect\.", r"eval\b", r"__import__", r"importlib"])
        taint_flow_proxy = int(has_user_input and (
            has_db_query or has_exec_call or has_output_write))
        cwe_numeric = severity_numeric = vuln_type_encoded = 0
        lang = (language or "python").lower()
        lang_python     = int(lang == "python")
        lang_java       = int(lang == "java")
        lang_javascript = int(lang in ("javascript", "js"))
        lang_cpp        = int(lang in ("cpp", "c++"))
        lang_c          = int(lang == "c")
        lang_php        = int(lang == "php")
        lang_go         = int(lang == "go")
        lang_rust       = int(lang == "rust")
        return np.array([
            loc, sloc, code_length, avg_line_length, comment_ratio,
            num_tokens, num_unique_tokens, lexical_diversity,
            num_functions, num_classes, num_imports, nesting_depth,
            num_conditionals, num_loops, num_try_catch, num_assertions,
            cyclomatic_proxy,
            has_user_input, has_db_query, has_exec_call, has_crypto,
            has_file_ops, has_network_ops, has_dangerous_func,
            has_hardcoded_secret, has_string_concat_query, has_output_write,
            has_rand, has_thread_ops, has_reflection, taint_flow_proxy,
            cwe_numeric, severity_numeric, vuln_type_encoded,
            lang_python, lang_java, lang_javascript, lang_cpp,
            lang_c, lang_php, lang_go, lang_rust,
        ], dtype=float).reshape(1, -1)

    # ── Prediction ────────────────────────────────────────────────────────────

    def predict(self, features: np.ndarray):
        """60/40 RF+GB ensemble. features shape: (1, 42)."""
        if not self.is_trained or not ML_AVAILABLE:
            return None
        import pandas as pd
        feat_df  = pd.DataFrame(features, columns=self.FEATURE_COLS)
        rf_prob  = self.rf_pipeline.predict_proba(feat_df)[0, 1]
        gb_prob  = self.gb_pipeline.predict_proba(feat_df)[0, 1]
        ens_prob = rf_prob * 0.6 + gb_prob * 0.4
        return {
            'probability': float(ens_prob),
            'risk_level':  self._get_risk_level(ens_prob),
            'rf_prob':     float(rf_prob),
            'gb_prob':     float(gb_prob),
            'prediction':  bool(ens_prob >= 0.5),
        }

    def _get_risk_level(self, prob: float) -> str:
        if prob >= 0.8:   return 'CRITICAL'
        elif prob >= 0.6: return 'HIGH'
        elif prob >= 0.4: return 'MEDIUM'
        elif prob >= 0.2: return 'LOW'
        else:             return 'VERY_LOW'

    # ── Model loading ─────────────────────────────────────────────────────────

    def load_pretrained_models(self, models_dir: str = 'models') -> bool:
        """
        Load self-contained sklearn Pipeline files from train_model.py.
        Each pipeline contains its own StandardScaler — no separate scaler file needed.

        Expected files:
          <models_dir>/randomforest_pipeline.pkl
          <models_dir>/gradientboosting_pipeline.pkl
          <models_dir>/training_summary_v2.json  (optional, for logging)

        Falls back to train_with_sample_data() if files are missing.
        """
        if not ML_AVAILABLE:
            return False

        rf_path      = os.path.join(models_dir, 'randomforest_pipeline.pkl')
        gb_path      = os.path.join(models_dir, 'gradientboosting_pipeline.pkl')
        summary_path = os.path.join(models_dir, 'training_summary_v2.json')

        if not (os.path.exists(rf_path) and os.path.exists(gb_path)):
            print("WARNING: Pipeline files not found in 'models/'. "
                  "Run train_model.py first. Falling back to sample training.")
            return self.train_with_sample_data()

        try:
            with open(rf_path, 'rb') as f:
                self.rf_pipeline = pickle.load(f)
            with open(gb_path, 'rb') as f:
                self.gb_pipeline = pickle.load(f)
            self.is_trained = True

            if os.path.exists(summary_path):
                with open(summary_path) as f:
                    summary = json.load(f)
                total  = summary.get('total_samples', '?')
                acc    = summary.get('ensemble_accuracy', 0)
                auc    = summary.get('ensemble_roc_auc', 0)
                n_feat = len(summary.get('feature_columns', self.FEATURE_COLS))
                print("Pre-trained ML pipelines loaded successfully.")
                print(f"  Dataset  : {total:,} samples | {n_feat} features | 8 languages")
                print(f"  Accuracy : {acc*100:.1f}%  |  ROC-AUC : {auc:.3f}")
            return True

        except Exception as exc:
            print(f"WARNING: Failed to load pipelines: {exc}. "
                  "Falling back to sample training.")
            return self.train_with_sample_data()

    def train_with_sample_data(self) -> bool:
        """
        Lightweight fallback: trains tiny RF+GB on synthetic data so the app
        remains functional without the real model files.
        Accuracy will be near-random — run train_model.py for real models.
        """
        if not ML_AVAILABLE:
            return False
        from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
        from sklearn.preprocessing import StandardScaler
        from sklearn.pipeline import Pipeline

        np.random.seed(42)
        n = len(self.FEATURE_COLS)
        X = np.random.randn(800, n)
        y = np.random.choice([0, 1], 800, p=[0.65, 0.35])

        self.rf_pipeline = Pipeline([
            ("scaler", StandardScaler()),
            ("model",  RandomForestClassifier(n_estimators=50, random_state=42)),
        ])
        self.gb_pipeline = Pipeline([
            ("scaler", StandardScaler()),
            ("model",  GradientBoostingClassifier(n_estimators=30, random_state=42)),
        ])
        self.rf_pipeline.fit(X, y)
        self.gb_pipeline.fit(X, y)
        self.is_trained = True
        print("WARNING: Using fallback synthetic models. Run train_model.py for real accuracy.")
        return True


# ─────────────────────────────────────────────────────────────────────────────
# LANGUAGE-SPECIFIC VULNERABILITY DETECTOR  (enhanced rule packs + FP reduction)
# ─────────────────────────────────────────────────────────────────────────────
class MultiLanguageVulnerabilityDetector:
    """
    Enhanced pattern detection with:
    - Language-specific deep rule packs
    - Context-aware false positive filtering
    - CWE mapping built-in
    """

    def __init__(self):
        self.language_patterns = self._initialize_patterns()
        self.fp_filters = self._initialize_fp_filters()

    def _initialize_patterns(self):
        return {
            'python': {
                'SQL Injection': [
                    (r'(?i)(execute|cursor\s*\.\s*execute)\s*\([^)]*\+', 'String concatenation in SQL execute'),
                    (r'(?i)f["\'].*(?:SELECT|INSERT|UPDATE|DELETE).*\{', 'F-string interpolation in SQL query'),
                    (r'(?i)(?:SELECT|INSERT|UPDATE|DELETE)[^;]*%\s*[\(\w]', 'String % formatting in SQL'),
                    (r'(?i)(SELECT|INSERT|UPDATE|DELETE).*\.format\s*\(', '.format() in SQL query'),
                ],
                'Command Injection': [
                    (r'os\.system\s*\([^)]*(?:\+|f["\']|\%|\.format)', 'os.system with dynamic input'),
                    (r'subprocess\.(?:run|call|check_output|Popen)\s*\([^)]*shell\s*=\s*True', 'subprocess with shell=True'),
                    (r'eval\s*\(\s*(?:input|request|sys\.argv)', 'eval() with user input'),
                    (r'exec\s*\(\s*(?:input|request|sys\.argv)', 'exec() with user input'),
                    (r'os\.popen\s*\([^)]*\+', 'os.popen with concatenation'),
                ],
                'Hardcoded Secrets': [
                    (r'(?i)(password|passwd|pwd)\s*=\s*["\'][^"\']{5,}["\'](?!\s*#\s*noqa)', 'Hardcoded password literal'),
                    (r'(?i)(api_key|apikey|api_secret)\s*=\s*["\'][^"\']{15,}["\']', 'Hardcoded API key'),
                    (r'(?i)(secret|private_key|secret_key)\s*=\s*["\'][^"\']{10,}["\']', 'Hardcoded secret'),
                    (r'(?i)(token|access_token|bearer)\s*=\s*["\'][^"\']{20,}["\']', 'Hardcoded token'),
                ],
                'Weak Cryptography': [
                    (r'hashlib\.md5\s*\((?!.*usedforsecurity=False)', 'MD5 hash (not safe for passwords)'),
                    (r'hashlib\.sha1\s*\((?!.*usedforsecurity=False)', 'SHA1 hash (collision vulnerable)'),
                    (r'(?i)Cipher\.new.*(?:DES|RC4|RC2)', 'Weak encryption algorithm'),
                ],
                'Unsafe Deserialization': [
                    (r'pickle\.loads?\s*\(', 'Unsafe pickle deserialization – RCE risk'),
                    (r'yaml\.load\s*\([^,)]*\)', 'yaml.load without Loader=yaml.SafeLoader'),
                    (r'marshal\.loads\s*\(', 'marshal.loads – unsafe deserialization'),
                    (r'jsonpickle\.decode\s*\(', 'jsonpickle.decode – unsafe deserialization'),
                ],
                'Path Traversal': [
                    (r'open\s*\([^)]*(?:request|input|argv|\+|f["\'])', 'open() with user-controlled path'),
                    (r'os\.path\.join\s*\([^)]*(?:request|input|\+)', 'os.path.join with user input'),
                ],
                'SSRF': [
                    (r'requests\.(get|post|put|delete)\s*\([^)]*(?:request|input|argv|\+)', 'SSRF via requests with user-controlled URL'),
                    (r'urllib\.request\.urlopen\s*\([^)]*(?:request|input|\+)', 'SSRF via urllib with user input'),
                ],
                'Insecure Random': [
                    (r'random\.(?:random|randint|choice|seed)\s*\(', 'Cryptographically weak random (use secrets module)'),
                ],
            },

            'javascript': {
                'XSS': [
                    (r'\.innerHTML\s*=\s*[^;]*(?:\+|`|\$\{|req\.|request\.)', 'innerHTML with dynamic/user data'),
                    (r'document\.write\s*\([^)]*(?:\+|\$\{|req\.)', 'document.write with dynamic content'),
                    (r'eval\s*\(', 'eval() – code injection risk'),
                    (r'dangerouslySetInnerHTML\s*=\s*\{\s*\{\s*__html', 'React dangerouslySetInnerHTML'),
                    (r'\.outerHTML\s*=\s*[^;]*\+', 'outerHTML with concatenation'),
                    (r'setTimeout\s*\(\s*(?:[\w]+\s*\+|`)', 'setTimeout with dynamic string (eval-like)'),
                ],
                'SQL Injection': [
                    (r'(?i)(query|execute)\s*\(\s*["\'].*\+', 'SQL query concatenation'),
                    (r'(?i)`\s*(?:SELECT|INSERT|UPDATE|DELETE).*\$\{', 'Template literal in SQL'),
                    (r'(?i)knex\.raw\s*\([^)]*\+', 'knex.raw with concatenation'),
                ],
                'Command Injection': [
                    (r'child_process\.\w+\s*\([^)]*\+', 'child_process with concatenation'),
                    (r'exec(Sync)?\s*\(`[^`]*\$\{', 'exec with template literal'),
                    (r'spawnSync?\s*\([^)]*\+', 'spawn with concatenation'),
                ],
                'Hardcoded Secrets': [
                    (r'(?i)(password|passwd|secret|token|apiKey|api_key)\s*[:=]\s*["\'][^"\']{8,}["\']', 'Hardcoded credential in object/variable'),
                ],
                'Prototype Pollution': [
                    (r'for\s*\(\s*(?:let|var|const)\s+\w+\s+in\s+\w+\s*\)\s*\{\s*\w+\[\w+\]\s*=\s*\w+\[\w+\]', 'Unsafe object merge – prototype pollution risk'),
                    (r'Object\.assign\s*\(\s*\w+\s*,\s*(?:req\.|request\.)', 'Object.assign with user data'),
                ],
                'Insecure Random': [
                    (r'Math\.random\s*\(\)', 'Math.random() – not cryptographically secure'),
                ],
                'ReDoS': [
                    (r'new\s+RegExp\s*\([^)]*(?:req\.|request\.|input)', 'RegExp with user-controlled pattern – ReDoS risk'),
                    (r'/\([a-zA-Z+*]\+\)\+/', 'Catastrophic backtracking regex pattern'),
                ],
                'Open Redirect': [
                    (r'(?:window\.location|location\.(?:href|replace|assign))\s*=\s*[^;]*(?:req\.|request\.|query\.)', 'Open redirect with user-controlled URL'),
                    (r'res\.redirect\s*\([^)]*(?:req\.|request\.|query\.)', 'res.redirect with user input'),
                ],
            },

            'java': {
                'SQL Injection': [
                    (r'(?i)(Statement|createStatement)\s*\(\s*\)', 'Non-parameterized Statement – use PreparedStatement'),
                    (r'(?i)(?:createQuery|createNativeQuery)\s*\([^)]*\+', 'JPA query with string concatenation'),
                    (r'(?i)(SELECT|INSERT|UPDATE|DELETE)[^;]*"\s*\+\s*\w+', 'SQL query built via string concatenation'),
                ],
                'Command Injection': [
                    (r'Runtime\.getRuntime\(\)\.exec\s*\([^)]*\+', 'Runtime.exec with user-controlled input'),
                    (r'new\s+ProcessBuilder\s*\([^)]*\+', 'ProcessBuilder with concatenation'),
                    (r'ProcessBuilder.*\.command\s*\([^)]*\+', 'ProcessBuilder.command with concatenation'),
                ],
                'Unsafe Deserialization': [
                    (r'ObjectInputStream\s*\(', 'ObjectInputStream – unsafe Java deserialization (CWE-502)'),
                    (r'readObject\s*\(\)', 'readObject() call – deserialization risk'),
                    (r'XMLDecoder\s*\(', 'XMLDecoder – arbitrary code execution risk'),
                ],
                'Path Traversal': [
                    (r'new\s+File(?:Reader|Writer|InputStream|OutputStream)\s*\([^)]*(?:getParameter|request\.)', 'File I/O with request parameter'),
                    (r'Paths\.get\s*\([^)]*(?:getParameter|\+)', 'Paths.get with user-controlled input'),
                ],
                'Hardcoded Secrets': [
                    (r'(?i)(password|secret|token)\s*=\s*"[^"]{5,}"', 'Hardcoded credential string'),
                ],
                'Sensitive Information Disclosure': [
                    (r'System\.out\.print[ln]*\s*\([^)]*(?:password|token|secret)', 'Sensitive data printed to stdout'),
                    (r'\.printStackTrace\s*\(\)', 'Stack trace exposed (information disclosure)'),
                    (r'\.getLogger.*\.(?:debug|info)\s*\([^)]*(?:password|secret|token)', 'Sensitive data in log statement'),
                ],
                'Weak Cryptography': [
                    (r'MessageDigest\.getInstance\s*\(\s*"(?:MD5|SHA-1|SHA1)"', 'Weak hash algorithm'),
                    (r'Cipher\.getInstance\s*\(\s*"(?:DES|RC4|RC2|AES/ECB)', 'Weak or insecure cipher mode'),
                    (r'SecureRandom\s*\(\)', 'Insecure SecureRandom instantiation'),
                ],
                'SSRF': [
                    (r'new\s+URL\s*\([^)]*(?:getParameter|request\.|\+)', 'URL instantiated from user input – SSRF risk'),
                ],
            },

            'cpp': {
                'Buffer Overflow': [
                    (r'\bstrcpy\s*\(', 'strcpy – use strncpy or strlcpy'),
                    (r'\bstrcat\s*\(', 'strcat – use strncat'),
                    (r'\bsprintf\s*\(', 'sprintf – use snprintf'),
                    (r'\bgets\s*\(', 'gets() – BANNED function, always vulnerable'),
                    (r'\bsscanf\s*\([^,]+,\s*"%[^"]*s"', 'Unbounded %s format in sscanf'),
                    (r'\bmemcpy\s*\([^)]+,\s*\w+\s*,\s*(?:strlen|sizeof)\s*\(\s*\w+\s*\)\s*\)', 'memcpy with unchecked source length'),
                ],
                'Format String': [
                    (r'\bprintf\s*\(\s*\w+\s*\)', 'printf with non-literal format string'),
                    (r'\bfprintf\s*\(\s*\w+\s*,\s*\w+\s*\)', 'fprintf with non-literal format string'),
                    (r'\bsprintf\s*\(\s*\w+\s*,\s*\w+\s*\)', 'sprintf with non-literal format string'),
                ],
                'Command Injection': [
                    (r'\bsystem\s*\(', 'system() – use execvp() with argument array'),
                    (r'\bpopen\s*\(', 'popen() – vulnerable to command injection'),
                    (r'\bexeclp?\s*\([^,]+,\s*[^,]+,\s*\w+', 'execl/execlp with user-controlled args'),
                ],
                'Integer Overflow': [
                    (r'(?:int|short|long)\s+\w+\s*=\s*\w+\s*\*\s*\w+', 'Integer multiplication without overflow check'),
                    (r'malloc\s*\(\s*\w+\s*\*\s*\w+\s*\)', 'malloc with unchecked multiplication – overflow risk'),
                ],
                'Use After Free': [
                    (r'free\s*\(\s*(\w+)\s*\)[^;]*\n[^;]*\1\b', 'Potential use-after-free pattern'),
                ],
                'Null Pointer Dereference': [
                    (r'malloc\s*\([^)]+\)\s*;\s*\n?\s*\*', 'Dereference of malloc return without NULL check'),
                ],
                'Race Condition': [
                    (r'(?:access|stat|lstat)\s*\([^)]+\)[^;]*\n[^;]*(?:open|fopen|exec)', 'TOCTOU race condition (check-then-use)'),
                ],
            },

            'php': {
                'SQL Injection': [
                    (r'(?i)mysql(?:i)?_query\s*\([^)]*\.\s*\$', 'mysql_query with string concatenation'),
                    (r'(?i)(SELECT|INSERT|UPDATE|DELETE).*\.\s*\$_(?:GET|POST|REQUEST)', 'SQL with superglobal concatenation'),
                    (r'(?i)->\s*query\s*\([^)]*\.\s*\$', 'PDO/mysqli query with concatenation'),
                ],
                'XSS': [
                    (r'echo\s+\$_(?:GET|POST|REQUEST|COOKIE)', 'Direct echo of user input – XSS'),
                    (r'print\s+\$_(?:GET|POST|REQUEST|COOKIE)', 'Direct print of user input – XSS'),
                    (r'<\?=\s*\$_(?:GET|POST|REQUEST)', 'Short echo tag with user input – XSS'),
                ],
                'Command Injection': [
                    (r'(?:exec|shell_exec|system|passthru|popen|proc_open)\s*\([^)]*\$_', 'Command execution with user-controlled input'),
                ],
                'File Inclusion': [
                    (r'(?:include|require|include_once|require_once)\s*[\(\s]\s*\$', 'Dynamic file inclusion with variable'),
                    (r'(?:include|require)\s*\([^)]*(?:GET|POST|REQUEST)', 'File inclusion with superglobal'),
                ],
                'Path Traversal': [
                    (r'file_get_contents\s*\([^)]*\$_(?:GET|POST)', 'file_get_contents with user-controlled path'),
                    (r'fopen\s*\([^)]*\$_(?:GET|POST)', 'fopen with user input'),
                ],
                'Hardcoded Secrets': [
                    (r'(?i)\$(?:password|passwd|secret|api_key|token)\s*=\s*["\'][^"\']{8,}["\']', 'Hardcoded PHP credential'),
                ],
            },

            'go': {
                'SQL Injection': [
                    (r'db\.(?:Query|Exec|QueryRow)\s*\(\s*(?:fmt\.Sprintf|["\'][^"\']*"\s*\+)', 'Go SQL with string formatting/concatenation'),
                    (r'fmt\.Sprintf.*(?:SELECT|INSERT|UPDATE|DELETE)', 'fmt.Sprintf used to build SQL'),
                ],
                'Command Injection': [
                    (r'exec\.Command\s*\([^)]*\+', 'exec.Command with string concatenation'),
                    (r'exec\.CommandContext\s*\([^)]*\+', 'exec.CommandContext with concatenation'),
                ],
                'SSRF': [
                    (r'http\.(?:Get|Post)\s*\([^)]*\+', 'http.Get/Post with user-controlled URL'),
                ],
                'Hardcoded Secrets': [
                    (r'(?i)(?:password|secret|token|apiKey)\s*:?=\s*"[^"]{8,}"', 'Hardcoded Go credential'),
                ],
                'Race Condition': [
                    (r'go\s+func\s*\(\)', 'Goroutine accessing shared state – verify mutex usage'),
                ],
            },

            'rust': {
                'SQL Injection': [
                    (r'\.execute\s*\(\s*&?format!\s*\(', 'SQL execute with format! macro'),
                    (r'\.query\s*\(\s*&?format!\s*\(', 'SQL query with format! macro'),
                ],
                'Command Injection': [
                    (r'Command::new\s*\([^)]*\+', 'Command::new with string concatenation'),
                    (r'\.arg\s*\([^)]*\.trim\s*\(\)', 'Command arg from trimmed user input'),
                ],
                'Hardcoded Secrets': [
                    (r'(?i)(?:password|secret|token|api_key)\s*=\s*"[^"]{8,}"', 'Hardcoded Rust credential'),
                ],
            },
        }

    def _initialize_fp_filters(self):
        """Context-aware false positive suppression rules."""
        return {
            'Hardcoded Secrets': [
                # Skip if value looks like an env var reference or placeholder
                r'(?i)(password|secret)\s*=\s*["\'](your_|example_|<|{|TODO|CHANGE|REPLACE|xxx|placeholder)',
                r'(?i)(password|secret)\s*=\s*["\']os\.environ',
                r'(?i)(password|secret)\s*=\s*["\']""',
                r'(?i)(password|secret)\s*=\s*["\']None',
            ],
            'Weak Cryptography': [
                # Skip MD5 used for non-security purposes (checksums, caching)
                r'#.*(?:checksum|non-security|cache|etag)',
            ],
        }

    def _is_false_positive(self, vuln_type, line_code):
        """Check if a finding is likely a false positive."""
        filters = self.fp_filters.get(vuln_type, [])
        for pat in filters:
            if re.search(pat, line_code, re.IGNORECASE):
                return True
        return False

    def detect_vulnerabilities(self, code, language, file_path):
        vulnerabilities = []
        lines = code.split('\n')
        lang_patterns = self.language_patterns.get(language.lower(), self._get_generic_patterns())

        for vuln_type, patterns in lang_patterns.items():
            cwe_info = CWE_MAP.get(vuln_type, {})
            remediation = REMEDIATION_MAP.get(vuln_type, "Apply security best practices.")
            for pattern, description in patterns:
                for line_num, line in enumerate(lines, 1):
                    if re.search(pattern, line, re.IGNORECASE):
                        if self._is_false_positive(vuln_type, line):
                            continue
                        vulnerabilities.append({
                            'type':        vuln_type,
                            'description': description,
                            'line':        line_num,
                            'code':        line.strip(),
                            'severity':    self._get_severity(vuln_type),
                            'file':        file_path,
                            'source':      'Pattern Detection',
                            'language':    language,
                            'cwe_id':      cwe_info.get('id', 'N/A'),
                            'cwe_name':    cwe_info.get('name', ''),
                            'cwe_url':     cwe_info.get('url', ''),
                            'remediation': remediation,
                            'taint_flow':  False,
                        })
        return vulnerabilities

    def _get_generic_patterns(self):
        return {
            'SQL Injection':     [(r'(?i)(SELECT|INSERT|UPDATE|DELETE).*\+', 'Potential SQL injection')],
            'Hardcoded Secrets': [(r'(?i)(password|secret|token|key)\s*=\s*["\'][^"\']{8,}', 'Hardcoded credential')],
            'Command Execution': [(r'(exec|system|shell)', 'Command execution detected')],
        }

    def _get_severity(self, vuln_type):
        critical = {'SQL Injection', 'Command Injection', 'Buffer Overflow', 'Unsafe Deserialization',
                    'File Inclusion', 'Format String', 'Use After Free'}
        high     = {'XSS', 'Hardcoded Secrets', 'Path Traversal', 'SSRF', 'Sensitive Information Disclosure',
                    'Prototype Pollution', 'Open Redirect'}
        medium   = {'Weak Cryptography', 'Insecure Random', 'ReDoS', 'Integer Overflow',
                    'Null Pointer Dereference', 'Race Condition'}
        if vuln_type in critical: return 'CRITICAL'
        if vuln_type in high:     return 'HIGH'
        if vuln_type in medium:   return 'MEDIUM'
        return 'LOW'


# ─────────────────────────────────────────────────────────────────────────────
# SEMGREP ANALYZER
# ─────────────────────────────────────────────────────────────────────────────
class SemgrepAnalyzer:
    def check_installation(self):
        try:
            result = subprocess.run(['semgrep', '--version'], capture_output=True, text=True, timeout=10)
            return result.returncode == 0
        except:
            return False

    def analyze(self, file_path):
        try:
            cmd = ['semgrep', '--config=auto', '--json', '--quiet', file_path]
            result = subprocess.run(cmd, capture_output=True, text=True,
                                    encoding='utf-8', errors='replace', timeout=30)
            if result.returncode == 0:
                findings = json.loads(result.stdout)
                semgrep_vulns = []
                for finding in findings.get('results', []):
                    vuln_type = finding.get('check_id', 'Unknown')
                    cwe_info = {}
                    # try to map semgrep check_id to CWE
                    for k, v in CWE_MAP.items():
                        if k.lower() in vuln_type.lower():
                            cwe_info = v
                            break
                    semgrep_vulns.append({
                        'type':        vuln_type,
                        'description': finding.get('extra', {}).get('message', 'Semgrep finding'),
                        'line':        finding.get('start', {}).get('line', 0),
                        'code':        finding.get('extra', {}).get('lines', ''),
                        'severity':    finding.get('extra', {}).get('severity', 'INFO').upper(),
                        'file':        file_path,
                        'source':      'Semgrep',
                        'cwe_id':      cwe_info.get('id', 'N/A'),
                        'cwe_name':    cwe_info.get('name', ''),
                        'cwe_url':     cwe_info.get('url', ''),
                        'remediation': REMEDIATION_MAP.get(vuln_type, ''),
                        'taint_flow':  False,
                    })
                return semgrep_vulns
        except Exception as e:
            print(f"Semgrep error: {e}")
        return []


# ─────────────────────────────────────────────────────────────────────────────
# RESPONSIVE FRAME
# ─────────────────────────────────────────────────────────────────────────────
class ResponsiveFrame(ttk.Frame):
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        self.bind('<Configure>', self.on_configure)

    def on_configure(self, event):
        if event.widget == self:
            self.update_layout()

    def update_layout(self):
        pass


# ─────────────────────────────────────────────────────────────────────────────
# MAIN GUI
# ─────────────────────────────────────────────────────────────────────────────
class EnhancedBugPredictionGUI:

    def __init__(self, root):
        self.root = root
        self._setup_window()
        self._setup_variables()
        self._setup_database()

        self.developer_metrics = DeveloperMetrics()
        self.ml_predictor      = MLSecurityPredictor()
        self.vuln_detector     = MultiLanguageVulnerabilityDetector()
        self.taint_engine      = TaintAnalysisEngine()
        self.semgrep_analyzer  = SemgrepAnalyzer()

        if ML_AVAILABLE:
            self.ml_predictor.load_pretrained_models(models_dir='models')

        self._create_modern_ui()
        self.current_results = None
        self.db_lock = threading.Lock()

    # ── window / variables / database ────────────────────────────────────────

    def _setup_window(self):
        self.root.title("🔒 Enhanced Security Bug Prediction System v4.0")
        sw, sh = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
        ww, wh = int(sw * 0.87), int(sh * 0.87)
        self.root.geometry(f"{ww}x{wh}+{(sw-ww)//2}+{(sh-wh)//2}")
        self.root.minsize(1100, 750)
        self.root.configure(bg='#0d1117')
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)

    def _setup_variables(self):
        self.selected_file         = tk.StringVar()
        self.selected_language     = tk.StringVar(value="python")
        self.analysis_status       = tk.StringVar(value="Ready")
        self.min_severity          = tk.StringVar(value="INFO")
        # Developer profile variables
        self.dev_name              = tk.StringVar(value="current_dev")
        self.dev_total_commits     = tk.IntVar(value=0)
        self.dev_bug_commits       = tk.IntVar(value=0)
        self.dev_components        = tk.StringVar(value="")

    def _setup_database(self):
        try:
            self.conn   = sqlite3.connect('bug_analysis_v4.db', check_same_thread=False)
            self.cursor = self.conn.cursor()
            self.cursor.execute('''
                CREATE TABLE IF NOT EXISTS analysis_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT, filename TEXT, language TEXT,
                    total_vulnerabilities INTEGER,
                    critical_count INTEGER, high_count INTEGER,
                    medium_count INTEGER, low_count INTEGER, info_count INTEGER,
                    taint_findings INTEGER,
                    ml_risk_level TEXT, ml_probability REAL,
                    results_json TEXT
                )
            ''')
            self.conn.commit()
        except Exception as e:
            print(f"Database error: {e}")

    # ── UI construction ──────────────────────────────────────────────────────

    def _create_modern_ui(self):
        self._setup_styles()
        self.main_container = ResponsiveFrame(self.root, style='Main.TFrame')
        self.main_container.grid(row=0, column=0, sticky='nsew', padx=10, pady=10)
        self.main_container.grid_rowconfigure(1, weight=1)
        self.main_container.grid_columnconfigure(0, weight=1)
        self._create_header()
        self._create_tabbed_interface()
        self._create_status_bar()

    def _setup_styles(self):
        style = ttk.Style()
        style.theme_use('clam')
        BG   = '#0d1117'; BG2 = '#161b22'; CARD = '#21262d'
        TXT  = '#c9d1d9'; BLUE = '#58a6ff'; GREEN = '#3fb950'
        RED  = '#f85149'; YEL  = '#d29922'; PUR = '#bc8cff'

        style.configure('Main.TFrame',    background=BG)
        style.configure('Header.TFrame',  background=BG2)
        style.configure('Header.TLabel',  background=BG2, foreground=BLUE,  font=('Segoe UI', 18, 'bold'))
        style.configure('Content.TFrame', background=CARD)
        style.configure('Content.TLabel', background=CARD, foreground=TXT,  font=('Segoe UI', 10))
        style.configure('Title.TLabel',   background=CARD, foreground=GREEN, font=('Segoe UI', 13, 'bold'))
        style.configure('Card.TFrame',    background=CARD, relief='solid', borderwidth=1)
        style.configure('Primary.TButton',   padding=12, font=('Segoe UI', 11, 'bold'))
        style.configure('Secondary.TButton', padding=8,  font=('Segoe UI', 9))
        style.configure('TNotebook',         background=BG, borderwidth=0)
        style.configure('TNotebook.Tab',     background=BG2, foreground=TXT, padding=[20, 10], font=('Segoe UI', 10, 'bold'))
        style.map('TNotebook.Tab', background=[('selected', CARD)], foreground=[('selected', BLUE)])

    def _create_header(self):
        hf = ttk.Frame(self.main_container, style='Header.TFrame')
        hf.grid(row=0, column=0, sticky='ew', pady=(0, 15))
        hf.grid_columnconfigure(0, weight=1)

        ttk.Label(hf, text="🔒 Enhanced Security Bug Prediction System v4.0",
                  style='Header.TLabel').grid(row=0, column=0, sticky='w', padx=20, pady=15)

        ml_ok    = ML_AVAILABLE and self.ml_predictor.is_trained
        eng_txt  = "⚡ Engines: Pattern · Taint · ML (Real-Trained, 80.2% acc) · Semgrep  —  All Active" if ml_ok else "⚡ Engines: Pattern · Taint · Semgrep  —  ML Unavailable"
        eng_color= '#3fb950' if ml_ok else '#d29922'
        tk.Label(hf, text=eng_txt, bg='#161b22', fg=eng_color,
                 font=('Segoe UI', 10, 'bold')).grid(row=0, column=1, sticky='e', padx=20, pady=15)

    def _create_tabbed_interface(self):
        self.notebook = ttk.Notebook(self.main_container)
        self.notebook.grid(row=1, column=0, sticky='nsew')

        self.analysis_frame  = ttk.Frame(self.notebook, style='Content.TFrame')
        self.results_frame   = ttk.Frame(self.notebook, style='Content.TFrame')
        self.dashboard_frame = ttk.Frame(self.notebook, style='Content.TFrame')
        self.history_frame   = ttk.Frame(self.notebook, style='Content.TFrame')

        self.notebook.add(self.analysis_frame,  text="  🔍 Analysis  ")
        self.notebook.add(self.results_frame,   text="  📊 Results  ")
        self.notebook.add(self.dashboard_frame, text="  📈 Dashboard  ")
        self.notebook.add(self.history_frame,   text="  📜 History  ")

        self._create_analysis_tab()
        self._create_results_tab()
        self._create_dashboard_tab()
        self._create_history_tab()

    def _create_analysis_tab(self):
        self.analysis_frame.grid_rowconfigure(3, weight=1)
        self.analysis_frame.grid_columnconfigure(0, weight=1)

        # ── File input
        inf = ttk.LabelFrame(self.analysis_frame, text="📁 Input Selection", style='Card.TFrame')
        inf.grid(row=0, column=0, sticky='ew', padx=20, pady=15)
        inf.grid_columnconfigure(1, weight=1)

        ttk.Label(inf, text="Select File/Directory:", style='Content.TLabel').grid(
            row=0, column=0, sticky='w', padx=15, pady=10)
        ef = ttk.Frame(inf, style='Content.TFrame')
        ef.grid(row=0, column=1, sticky='ew', padx=5, pady=10)
        ef.grid_columnconfigure(0, weight=1)
        tk.Entry(ef, textvariable=self.selected_file, bg='#161b22', fg='#c9d1d9',
                 font=('Consolas', 10), relief='flat', state='readonly').grid(
            row=0, column=0, sticky='ew', ipady=5)
        bf = ttk.Frame(inf, style='Content.TFrame')
        bf.grid(row=0, column=2, padx=5, pady=10)
        ttk.Button(bf, text="📁 File",      command=self._browse_file,      style='Secondary.TButton').pack(side='left', padx=3)
        ttk.Button(bf, text="📂 Directory", command=self._browse_directory, style='Secondary.TButton').pack(side='left', padx=3)

        cf = ttk.Frame(inf, style='Content.TFrame')
        cf.grid(row=1, column=0, columnspan=3, sticky='ew', padx=15, pady=10)
        ttk.Label(cf, text="Language:", style='Content.TLabel').grid(row=0, column=0, sticky='w', padx=(0, 10))
        ttk.Combobox(cf, textvariable=self.selected_language,
                     values=['python', 'javascript', 'java', 'cpp', 'php', 'go', 'rust'],
                     state='readonly', width=15).grid(row=0, column=1, sticky='w', padx=(0, 30))
        ttk.Label(cf, text="Min Severity:", style='Content.TLabel').grid(row=0, column=2, sticky='w', padx=(0, 10))
        ttk.Combobox(cf, textvariable=self.min_severity,
                     values=['INFO', 'LOW', 'MEDIUM', 'HIGH', 'CRITICAL'],
                     state='readonly', width=12).grid(row=0, column=3, sticky='w')

        # ── Code input
        cdf = ttk.LabelFrame(self.analysis_frame, text="💻 Direct Code Input", style='Card.TFrame')
        cdf.grid(row=1, column=0, sticky='ew', padx=20, pady=(0, 15))
        cdf.grid_rowconfigure(0, weight=1)
        cdf.grid_columnconfigure(0, weight=1)
        self.code_input = scrolledtext.ScrolledText(
            cdf, bg='#0d1117', fg='#c9d1d9', insertbackground='#58a6ff',
            selectbackground='#1f6feb', font=('Consolas', 10),
            height=10, wrap=tk.WORD, relief='flat')
        self.code_input.grid(row=0, column=0, sticky='nsew', padx=12, pady=12)

        ttk.Button(self.analysis_frame,
                   text="🔍 ANALYZE CODE FOR SECURITY VULNERABILITIES",
                   command=self._start_analysis, style='Primary.TButton').grid(
            row=3, column=0, pady=20, ipady=5, ipadx=30)

    def _create_results_tab(self):
        self.results_frame.grid_rowconfigure(1, weight=1)
        self.results_frame.grid_columnconfigure(0, weight=1)

        rh = ttk.Frame(self.results_frame, style='Content.TFrame')
        rh.grid(row=0, column=0, sticky='ew', padx=20, pady=15)
        rh.grid_columnconfigure(0, weight=1)
        ttk.Label(rh, text="📊 Analysis Results", style='Title.TLabel').grid(row=0, column=0, sticky='w')
        ef = ttk.Frame(rh, style='Content.TFrame')
        ef.grid(row=0, column=1, sticky='e')
        for fmt, lbl in [('json', '📄 JSON'), ('csv', '📊 CSV'), ('html', '🌐 HTML')]:
            ttk.Button(ef, text=lbl, command=lambda f=fmt: self._export_results(f),
                       style='Secondary.TButton').pack(side='left', padx=3)

        rc = ttk.Frame(self.results_frame, style='Card.TFrame')
        rc.grid(row=1, column=0, sticky='nsew', padx=20, pady=(0, 20))
        rc.grid_rowconfigure(0, weight=1)
        rc.grid_columnconfigure(0, weight=1)
        self.results_text = scrolledtext.ScrolledText(
            rc, bg='#0d1117', fg='#c9d1d9', insertbackground='#58a6ff',
            selectbackground='#1f6feb', font=('Consolas', 9),
            wrap=tk.WORD, state='disabled', relief='flat')
        self.results_text.grid(row=0, column=0, sticky='nsew', padx=12, pady=12)

        self.results_text.tag_configure('critical', foreground='#ff6b6b', font=('Consolas', 10, 'bold'))
        self.results_text.tag_configure('high',     foreground='#ffa500', font=('Consolas', 10, 'bold'))
        self.results_text.tag_configure('medium',   foreground='#ffd93d', font=('Consolas', 10, 'bold'))
        self.results_text.tag_configure('low',      foreground='#6bcf7f', font=('Consolas', 10, 'bold'))
        self.results_text.tag_configure('info',     foreground='#6bcbff', font=('Consolas', 10, 'bold'))
        self.results_text.tag_configure('header',   foreground='#58a6ff', font=('Consolas', 11, 'bold'))
        self.results_text.tag_configure('ml',       foreground='#bc8cff', font=('Consolas', 10, 'bold'))
        self.results_text.tag_configure('taint',    foreground='#ff9f43', font=('Consolas', 10, 'bold'))
        self.results_text.tag_configure('success',  foreground='#3fb950', font=('Consolas', 10, 'bold'))
        self.results_text.tag_configure('cwe',      foreground='#a29bfe', font=('Consolas', 9))
        self.results_text.tag_configure('fix',      foreground='#55efc4', font=('Consolas', 9))

    def _create_dashboard_tab(self):
        self.dashboard_frame.grid_rowconfigure(1, weight=1)
        self.dashboard_frame.grid_columnconfigure(0, weight=1)
        sc = ttk.Frame(self.dashboard_frame, style='Content.TFrame')
        sc.grid(row=0, column=0, sticky='ew', padx=20, pady=20)
        for i in range(5):
            sc.grid_columnconfigure(i, weight=1)
        self._create_stat_card(sc, "📊 Total Scans",    "0", "#58a6ff", 0)
        self._create_stat_card(sc, "⛔ Critical Issues", "0", "#ff6b6b", 1)
        self._create_stat_card(sc, "🔗 Taint Findings",  "0", "#ff9f43", 2)
        self._create_stat_card(sc, "📁 Files Analyzed",  "0", "#3fb950", 3)
        self._create_stat_card(sc, "✅ Clean Files",      "0%", "#ffd93d", 4)

        chart_f = ttk.LabelFrame(self.dashboard_frame, text="📈 Vulnerability Trends & Stats", style='Card.TFrame')
        chart_f.grid(row=1, column=0, sticky='nsew', padx=20, pady=(0, 20))
        chart_f.grid_rowconfigure(0, weight=1)
        chart_f.grid_columnconfigure(0, weight=1)
        self.dashboard_text = scrolledtext.ScrolledText(
            chart_f, bg='#0d1117', fg='#c9d1d9', font=('Consolas', 9),
            state='disabled', relief='flat', height=12)
        self.dashboard_text.grid(row=0, column=0, sticky='nsew', padx=12, pady=12)

    def _create_stat_card(self, parent, title, value, color, column):
        card = tk.Frame(parent, bg='#21262d', relief='solid', borderwidth=1)
        card.grid(row=0, column=column, sticky='ew', padx=8, pady=5)
        tk.Label(card, text=title,  bg='#21262d', fg='#8b949e', font=('Segoe UI', 9)).pack(pady=(15, 5))
        lbl = tk.Label(card, text=value, bg='#21262d', fg=color, font=('Segoe UI', 22, 'bold'))
        lbl.pack(pady=(0, 15))
        key = re.sub(r'[^a-z_]', '', title.lower().replace(' ', '_'))
        setattr(self, f"_stat_{key}", lbl)

    def _create_history_tab(self):
        self.history_frame.grid_rowconfigure(1, weight=1)
        self.history_frame.grid_columnconfigure(0, weight=1)
        hh = ttk.Frame(self.history_frame, style='Content.TFrame')
        hh.grid(row=0, column=0, sticky='ew', padx=20, pady=15)
        hh.grid_columnconfigure(0, weight=1)
        ttk.Label(hh, text="📜 Analysis History", style='Title.TLabel').grid(row=0, column=0, sticky='w')
        ttk.Button(hh, text="🔄 Refresh", command=self._refresh_history,
                   style='Secondary.TButton').grid(row=0, column=1, sticky='e')

        hc = ttk.Frame(self.history_frame, style='Card.TFrame')
        hc.grid(row=1, column=0, sticky='nsew', padx=20, pady=(0, 20))
        hc.grid_rowconfigure(0, weight=1)
        hc.grid_columnconfigure(0, weight=1)
        cols = ('Timestamp', 'File', 'Language', 'Total', 'Critical', 'Taint', 'ML Risk')
        self.history_tree = ttk.Treeview(hc, columns=cols, show='headings', height=15)
        for col in cols:
            self.history_tree.heading(col, text=col)
            self.history_tree.column(col, width=130, anchor='center')
        vs = ttk.Scrollbar(hc, orient='vertical', command=self.history_tree.yview)
        self.history_tree.configure(yscrollcommand=vs.set)
        self.history_tree.grid(row=0, column=0, sticky='nsew', padx=12, pady=12)
        vs.grid(row=0, column=1, sticky='ns', pady=12)

    def _create_status_bar(self):
        sf = ttk.Frame(self.main_container, style='Header.TFrame')
        sf.grid(row=2, column=0, sticky='ew', pady=(10, 0))
        sf.grid_columnconfigure(1, weight=1)
        self.status_label = tk.Label(sf, text="✅ Ready to analyze code",
                                     bg='#161b22', fg='#3fb950', font=('Segoe UI', 9, 'bold'))
        self.status_label.grid(row=0, column=0, sticky='w', padx=20, pady=10)
        self.progress_bar = ttk.Progressbar(sf, mode='indeterminate')
        self.progress_bar.grid(row=0, column=1, sticky='ew', padx=20, pady=10)

    # ── File browsing ─────────────────────────────────────────────────────────

    def _browse_file(self):
        filetypes = [
            ("Python files", "*.py"), ("JavaScript files", "*.js"),
            ("Java files", "*.java"), ("C/C++ files", "*.c *.cpp *.h *.hpp"),
            ("PHP files", "*.php"), ("Go files", "*.go"),
            ("Rust files", "*.rs"), ("All files", "*.*")
        ]
        filename = filedialog.askopenfilename(title="Select a file", filetypes=filetypes)
        if filename:
            self.selected_file.set(filename)
            ext = Path(filename).suffix.lower()
            lang_map = {'.py': 'python', '.js': 'javascript', '.java': 'java',
                        '.c': 'cpp', '.cpp': 'cpp', '.php': 'php', '.go': 'go', '.rs': 'rust'}
            if ext in lang_map:
                self.selected_language.set(lang_map[ext])

    def _browse_directory(self):
        dirname = filedialog.askdirectory(title="Select a directory")
        if dirname:
            self.selected_file.set(f"Directory: {dirname}")

    # ── Analysis orchestration ────────────────────────────────────────────────

    def _start_analysis(self):
        self.status_label.config(text="🔄 Analyzing…", fg='#ffa500')
        self.progress_bar.start()
        threading.Thread(target=self._run_analysis, daemon=True).start()

    def _run_analysis(self):
        try:
            file_path    = self.selected_file.get()
            code_content = self.code_input.get(1.0, tk.END).strip()
            if code_content:
                results = self._analyze_direct_code(code_content)
            elif file_path:
                if file_path.startswith("Directory:"):
                    results = self._analyze_directory(file_path.replace("Directory: ", ""))
                else:
                    results = self._analyze_file(file_path)
            else:
                results = {"error": "No input provided"}
            self.root.after(0, self._display_results, results)
        except Exception as e:
            self.root.after(0, self._display_results, {"error": f"Analysis failed: {e}"})
        finally:
            self.root.after(0, self._stop_progress)

    def _stop_progress(self):
        self.progress_bar.stop()
        self.status_label.config(text="✅ Ready to analyze code", fg='#3fb950')

    def _analyze_direct_code(self, code_content):
        try:
            with tempfile.NamedTemporaryFile(
                    mode='w', suffix=f'.{self.selected_language.get()}',
                    delete=False, encoding='utf-8') as tmp:
                tmp.write(code_content)
                tmp_path = tmp.name
            results = self._analyze_file(tmp_path, is_temp=True)
            os.unlink(tmp_path)
            return results
        except Exception as e:
            return {"error": f"Failed to analyze code: {e}"}

    def _analyze_file(self, file_path, is_temp=False):
        try:
            with open(file_path, 'r', encoding='utf-8', errors='replace') as f:
                code = f.read()

            language = self.selected_language.get()
            vulnerabilities = []
            ml_prediction   = None

            # 1. Language-specific pattern detection
            pattern_vulns = self.vuln_detector.detect_vulnerabilities(code, language, file_path)
            vulnerabilities.extend(pattern_vulns)

            # 2. Taint analysis (data-flow) — always active
            if True:
                taint_vulns = self.taint_engine.analyze(code, language)
                for tv in taint_vulns:
                    cwe_info = CWE_MAP.get(tv['type'], {})
                    tv['file']        = file_path
                    tv['language']    = language
                    tv['description'] = tv['explanation']
                    tv['line']        = tv['sink_line']
                    tv['code']        = tv['sink_code']
                    tv['cwe_id']      = cwe_info.get('id', 'N/A')
                    tv['cwe_name']    = cwe_info.get('name', '')
                    tv['cwe_url']     = cwe_info.get('url', '')
                    tv['remediation'] = REMEDIATION_MAP.get(tv['type'], '')
                    vulnerabilities.append(tv)

            # 3. Semgrep — always active if installed
            if self.semgrep_analyzer.check_installation():
                vulnerabilities.extend(self.semgrep_analyzer.analyze(file_path))

            # 4. ML prediction — always active
            if self.ml_predictor.is_trained:
                features = self.ml_predictor.extract_features(code, file_path, self.developer_metrics, language)
                ml_prediction = self.ml_predictor.predict(features)

            # Filter by min severity
            sev_order = {'INFO': 0, 'LOW': 1, 'MEDIUM': 2, 'HIGH': 3, 'CRITICAL': 4}
            min_lvl   = sev_order.get(self.min_severity.get(), 0)
            vulnerabilities = [v for v in vulnerabilities if sev_order.get(v.get('severity', 'INFO'), 0) >= min_lvl]

            # Deduplicate: same type + line + source
            seen = set()
            deduped = []
            for v in vulnerabilities:
                key = (v.get('type'), v.get('line'), v.get('source'))
                if key not in seen:
                    seen.add(key)
                    deduped.append(v)
            vulnerabilities = deduped

            categorized   = self._categorize(vulnerabilities)
            taint_count   = sum(1 for v in vulnerabilities if v.get('taint_flow'))

            self.root.after(0, lambda: self._save_result(
                file_path, categorized, vulnerabilities, ml_prediction, taint_count))

            return {
                'file': file_path, 'language': language,
                'vulnerabilities': vulnerabilities,
                'summary': categorized,
                'total': len(vulnerabilities),
                'taint_count': taint_count,
                'ml_prediction': ml_prediction,
                'is_temp': is_temp,
            }
        except Exception as e:
            return {"error": f"Failed to analyze {file_path}: {e}"}

    def _analyze_directory(self, dir_path):
        results = []
        ext_map = {'.py': 'python', '.js': 'javascript', '.java': 'java',
                   '.c': 'cpp', '.cpp': 'cpp', '.h': 'cpp', '.hpp': 'cpp',
                   '.php': 'php', '.go': 'go', '.rs': 'rust'}
        try:
            for root, dirs, files in os.walk(dir_path):
                for file in files:
                    fp  = os.path.join(root, file)
                    ext = Path(fp).suffix.lower()
                    if ext in ext_map:
                        self.selected_language.set(ext_map[ext])
                        r = self._analyze_file(fp)
                        if "error" not in r:
                            results.append(r)
            return {
                'directory': dir_path, 'files_analyzed': len(results),
                'results': results,
                'total_vulnerabilities': sum(r.get('total', 0) for r in results),
            }
        except Exception as e:
            return {"error": f"Failed to analyze directory: {e}"}

    def _categorize(self, vulnerabilities):
        cats = {s: [] for s in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']}
        for v in vulnerabilities:
            sev = v.get('severity', 'INFO')
            cats.setdefault(sev, []).append(v)
        return cats

    # ── Database ──────────────────────────────────────────────────────────────

    def _save_result(self, filename, categorized, vulnerabilities, ml_prediction, taint_count):
        try:
            with self.db_lock:
                ts       = datetime.now().isoformat()
                language = self.selected_language.get()
                total    = len(vulnerabilities)
                crit = len(categorized.get('CRITICAL', []))
                high = len(categorized.get('HIGH', []))
                med  = len(categorized.get('MEDIUM', []))
                low  = len(categorized.get('LOW', []))
                info = len(categorized.get('INFO', []))
                ml_risk = ml_prediction['risk_level'] if ml_prediction else 'N/A'
                ml_prob = ml_prediction['probability'] if ml_prediction else 0.0

                safe_v = [{k: str(v) if isinstance(v, (set, bool)) else v for k, v in vuln.items()}
                          for vuln in vulnerabilities]
                results_json = json.dumps({'vulnerabilities': safe_v, 'ml_prediction': ml_prediction}, indent=2)

                self.cursor.execute('''
                    INSERT INTO analysis_results
                    (timestamp, filename, language, total_vulnerabilities,
                     critical_count, high_count, medium_count, low_count, info_count,
                     taint_findings, ml_risk_level, ml_probability, results_json)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ''', (ts, filename, language, total, crit, high, med, low, info,
                      taint_count, ml_risk, ml_prob, results_json))
                self.conn.commit()
                self.root.after(0, self._update_dashboard)
        except Exception as e:
            print(f"DB save error: {e}")

    def _update_dashboard(self):
        try:
            with self.db_lock:
                self.cursor.execute('SELECT COUNT(*) FROM analysis_results')
                total_scans = self.cursor.fetchone()[0]
                self.cursor.execute('SELECT SUM(critical_count) FROM analysis_results')
                crit_issues = self.cursor.fetchone()[0] or 0
                self.cursor.execute('SELECT SUM(taint_findings) FROM analysis_results')
                taint_total = self.cursor.fetchone()[0] or 0
                self.cursor.execute('SELECT COUNT(DISTINCT filename) FROM analysis_results')
                files_analyzed = self.cursor.fetchone()[0]
                self.cursor.execute('SELECT COUNT(*) FROM analysis_results WHERE critical_count = 0 AND high_count = 0')
                clean = self.cursor.fetchone()[0]
                clean_pct = f"{clean / total_scans * 100:.1f}%" if total_scans else "0%"

                for attr, val in [
                    ('_stat_total_scans',    str(total_scans)),
                    ('_stat_critical_issues', str(crit_issues)),
                    ('_stat_taint_findings',  str(taint_total)),
                    ('_stat_files_analyzed',  str(files_analyzed)),
                    ('_stat_clean_files',     clean_pct),
                ]:
                    lbl = getattr(self, attr, None)
                    if lbl:
                        lbl.config(text=val)

                # Update dashboard text with breakdown
                self.cursor.execute('''
                    SELECT filename, language, total_vulnerabilities, critical_count, taint_findings, ml_risk_level
                    FROM analysis_results ORDER BY timestamp DESC LIMIT 5
                ''')
                rows = self.cursor.fetchall()
                self.dashboard_text.config(state='normal')
                self.dashboard_text.delete(1.0, tk.END)
                self.dashboard_text.insert(tk.END, "═══ Recent Analysis Summary ═══\n\n")
                for r in rows:
                    fname, lang, total, crit, taint, ml_risk = r
                    self.dashboard_text.insert(tk.END,
                        f"📁 {os.path.basename(fname):30} | {lang:12} | "
                        f"Total:{total:3}  Critical:{crit:3}  Taint:{taint:3}  ML:{ml_risk}\n")
                self.dashboard_text.config(state='disabled')
        except Exception as e:
            print(f"Dashboard update error: {e}")

    # ── Result display ────────────────────────────────────────────────────────

    def _display_results(self, results):
        self.current_results = results
        rt = self.results_text
        rt.config(state='normal')
        rt.delete(1.0, tk.END)

        if "error" in results:
            rt.insert(tk.END, f"❌ Error: {results['error']}\n", 'high')
            rt.config(state='disabled')
            return

        if 'directory' in results:
            self._display_directory_results(results)
            return

        # ── Header
        rt.insert(tk.END, "═" * 110 + "\n", 'header')
        rt.insert(tk.END, "🔒 SECURITY ANALYSIS REPORT — Enhanced v4.0\n", 'header')
        rt.insert(tk.END, "═" * 110 + "\n\n", 'header')
        rt.insert(tk.END, f"📁 File     : {os.path.basename(results.get('file', 'Unknown'))}\n")
        rt.insert(tk.END, f"💻 Language : {results.get('language', 'Unknown')}\n")
        rt.insert(tk.END, f"🔍 Total    : {results.get('total', 0)} vulnerabilities "
                           f"({results.get('taint_count', 0)} from taint analysis)\n\n")

        # ── Architecture summary
        rt.insert(tk.END, "🏗️  DETECTION ENGINE PIPELINE\n", 'header')
        rt.insert(tk.END, "─" * 110 + "\n")
        pattern_cnt = sum(1 for v in results.get('vulnerabilities', []) if v.get('source') == 'Pattern Detection')
        taint_cnt   = results.get('taint_count', 0)
        ml_cnt      = 1 if results.get('ml_prediction') else 0
        semgrep_cnt = sum(1 for v in results.get('vulnerabilities', []) if v.get('source') == 'Semgrep')
        rt.insert(tk.END, f"   ✅ Pattern Detection  → {pattern_cnt} findings\n")
        rt.insert(tk.END, f"   ✅ Taint Analysis      → {taint_cnt} data-flow findings\n", 'taint')
        rt.insert(tk.END, f"   ✅ ML Ensemble (RF+GB) → {'Active' if ml_cnt else 'Offline'}\n", 'ml')
        rt.insert(tk.END, f"   ✅ Semgrep             → {semgrep_cnt} findings\n\n")

        # ── ML Prediction
        if results.get('ml_prediction'):
            ml = results['ml_prediction']
            rt.insert(tk.END, "🤖 ML SECURITY PREDICTION (Random Forest + Gradient Boosting Ensemble)\n", 'ml')
            rt.insert(tk.END, "─" * 110 + "\n")
            risk_tag = ml['risk_level'].lower() if ml['risk_level'] != 'VERY_LOW' else 'low'
            rt.insert(tk.END, f"   Risk Level   : {ml['risk_level']}\n", risk_tag)
            rt.insert(tk.END, f"   Probability  : {ml['probability']:.1%}  "
                               f"(RF:{ml['rf_prob']:.1%}  GB:{ml['gb_prob']:.1%})\n")
            rt.insert(tk.END, f"   Verdict      : {'⚠️  SECURITY RISK DETECTED' if ml['prediction'] else '✅ LOW RISK'}\n\n",
                      risk_tag)

        # ── Taint Analysis findings (highlighted separately)
        taint_findings = [v for v in results.get('vulnerabilities', []) if v.get('taint_flow')]
        if taint_findings:
            rt.insert(tk.END, "🔗 TAINT ANALYSIS — DATA FLOW FINDINGS\n", 'taint')
            rt.insert(tk.END, "─" * 110 + "\n")
            rt.insert(tk.END, "   These findings trace user-controlled input flowing into dangerous sinks.\n\n")
            for i, v in enumerate(taint_findings, 1):
                sev_tag = v['severity'].lower()
                rt.insert(tk.END, f"   {i}. [{v['severity']}] {v['type']}\n", sev_tag)
                rt.insert(tk.END, f"      📡 Source (line {v.get('source_line','?')}): {v.get('source_code','')[:80]}\n")
                rt.insert(tk.END, f"      💀 Sink   (line {v.get('sink_line','?')}) : {v.get('sink_code','')[:80]}\n")
                rt.insert(tk.END, f"      🗣️  Explanation: {v.get('explanation','')}\n")
                if v.get('cwe_id') != 'N/A':
                    rt.insert(tk.END, f"      🏷️  {v['cwe_id']} – {v.get('cwe_name','')}\n", 'cwe')
                rt.insert(tk.END, f"      🔧 Fix: {v.get('remediation','')}\n\n", 'fix')

        # ── Pattern / Semgrep findings by severity
        non_taint = [v for v in results.get('vulnerabilities', []) if not v.get('taint_flow')]
        summary = self._categorize(non_taint)

        for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW', 'INFO']:
            vulns = summary.get(severity, [])
            if not vulns:
                continue
            icons = {'CRITICAL': '⛔', 'HIGH': '🔴', 'MEDIUM': '🟡', 'LOW': '🟢', 'INFO': '🔵'}
            tag = severity.lower()
            rt.insert(tk.END, f"\n{icons[severity]} {severity} SEVERITY ({len(vulns)})\n", tag)
            rt.insert(tk.END, "─" * 110 + "\n")
            for i, v in enumerate(vulns, 1):
                rt.insert(tk.END, f"\n  {i}. {v['type']}\n", tag)
                rt.insert(tk.END, f"     📝 {v['description']}\n")
                rt.insert(tk.END, f"     📍 Line {v['line']}: {v['code'][:130]}\n")
                if v.get('cwe_id') and v.get('cwe_id') != 'N/A':
                    rt.insert(tk.END, f"     🏷️  {v['cwe_id']} – {v.get('cwe_name','')}\n", 'cwe')
                if v.get('remediation'):
                    rt.insert(tk.END, f"     🔧 Fix: {v['remediation']}\n", 'fix')
                rt.insert(tk.END, f"     🔧 Source: {v.get('source', 'Pattern Detection')}\n")

        if results.get('total', 0) == 0:
            rt.insert(tk.END, "\n✅ No vulnerabilities detected!\n", 'success')

        rt.config(state='disabled')
        self.notebook.select(self.results_frame)
        self.root.after(100, self._refresh_history)

    def _display_directory_results(self, results):
        rt = self.results_text
        rt.insert(tk.END, "═" * 110 + "\n", 'header')
        rt.insert(tk.END, "📂 DIRECTORY ANALYSIS REPORT\n", 'header')
        rt.insert(tk.END, "═" * 110 + "\n\n", 'header')
        rt.insert(tk.END, f"📂 Directory     : {results['directory']}\n")
        rt.insert(tk.END, f"📄 Files Analyzed: {results['files_analyzed']}\n")
        rt.insert(tk.END, f"🔍 Total Vulns   : {results['total_vulnerabilities']}\n\n")

        for fr in results['results']:
            fname = os.path.basename(fr['file'])
            rt.insert(tk.END, "\n" + "═" * 110 + "\n", 'header')
            rt.insert(tk.END, f"📁 {fname}  [{fr.get('language', '?')}]  — {fr['total']} findings "
                               f"({fr.get('taint_count', 0)} taint)\n", 'header')
            rt.insert(tk.END, "═" * 110 + "\n")
            if fr.get('ml_prediction'):
                ml = fr['ml_prediction']
                risk_tag = ml['risk_level'].lower() if ml['risk_level'] != 'VERY_LOW' else 'low'
                rt.insert(tk.END, f"   🤖 ML Risk: {ml['risk_level']} ({ml['probability']:.1%})\n", risk_tag)

            for sev in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
                vulns = fr.get('summary', {}).get(sev, [])
                if vulns:
                    tag  = sev.lower()
                    icons = {'CRITICAL': '⛔', 'HIGH': '🔴', 'MEDIUM': '🟡', 'LOW': '🟢'}
                    rt.insert(tk.END, f"\n   {icons[sev]} {sev} ({len(vulns)})\n", tag)
                    for i, v in enumerate(vulns, 1):
                        rt.insert(tk.END, f"      {i}. {v['type']} (Line {v['line']}) — {v['description']}\n", tag)
                        if v.get('cwe_id') and v['cwe_id'] != 'N/A':
                            rt.insert(tk.END, f"         🏷️  {v['cwe_id']} – {v.get('cwe_name','')}\n", 'cwe')
                        if v.get('remediation'):
                            rt.insert(tk.END, f"         🔧 {v['remediation']}\n", 'fix')
        rt.config(state='disabled')
        self.notebook.select(self.results_frame)

    # ── History ───────────────────────────────────────────────────────────────

    def _refresh_history(self):
        try:
            with self.db_lock:
                for item in self.history_tree.get_children():
                    self.history_tree.delete(item)
                self.cursor.execute('''
                    SELECT timestamp, filename, language, total_vulnerabilities,
                           critical_count, taint_findings, ml_risk_level
                    FROM analysis_results ORDER BY timestamp DESC LIMIT 100
                ''')
                for row in self.cursor.fetchall():
                    ts, fn, lang, total, crit, taint, ml_risk = row
                    dt = datetime.fromisoformat(ts).strftime("%Y-%m-%d %H:%M")
                    self.history_tree.insert('', 'end',
                        values=(dt, os.path.basename(fn), lang, total, crit, taint, ml_risk))
        except Exception as e:
            print(f"History refresh error: {e}")

    # ── Export ────────────────────────────────────────────────────────────────

    def _export_results(self, fmt):
        try:
            if not self.current_results or "error" in self.current_results:
                messagebox.showwarning("Export Warning", "No results to export!")
                return
            ftype_map = {'json': [("JSON", "*.json")], 'csv': [("CSV", "*.csv")], 'html': [("HTML", "*.html")]}
            fp = filedialog.asksaveasfilename(
                title=f"Export as {fmt.upper()}",
                filetypes=ftype_map[fmt],
                defaultextension=f".{fmt}")
            if fp:
                {'json': self._export_json, 'csv': self._export_csv, 'html': self._export_html}[fmt](fp)
                messagebox.showinfo("Export Complete", f"✅ Results exported to:\n{fp}")
        except Exception as e:
            messagebox.showerror("Export Error", f"Failed to export: {e}")

    def _export_json(self, fp):
        safe = {k: v if isinstance(v, (list, dict)) else str(v)
                for k, v in self.current_results.items()}
        with open(fp, 'w', encoding='utf-8') as f:
            json.dump(safe, f, indent=2, default=str)

    def _export_csv(self, fp):
        import csv
        vulns = self.current_results.get('vulnerabilities', [])
        with open(fp, 'w', newline='', encoding='utf-8') as f:
            fields = ['type', 'severity', 'line', 'description', 'code', 'file',
                      'source', 'cwe_id', 'cwe_name', 'taint_flow', 'remediation']
            if vulns:
                w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
                w.writeheader()
                w.writerows(vulns)
            else:
                csv.writer(f).writerow(['No vulnerabilities found'])

    def _export_html(self, fp):
        ml   = self.current_results.get('ml_prediction', {})
        summ = self.current_results.get('summary', {})
        all_vulns = self.current_results.get('vulnerabilities', [])
        taint_vulns = [v for v in all_vulns if v.get('taint_flow')]

        crit_c = len(summ.get('CRITICAL', []))
        high_c = len(summ.get('HIGH', []))
        med_c  = len(summ.get('MEDIUM', []))
        low_c  = len(summ.get('LOW', []))

        html = f"""<!DOCTYPE html>
<html>
<head>
<title>Security Analysis Report v4.0</title>
<meta charset="utf-8">
<style>
  body{{font-family:'Segoe UI',Arial,sans-serif;margin:0;padding:20px;background:#0d1117;color:#c9d1d9}}
  .container{{max-width:1400px;margin:0 auto;background:#161b22;padding:30px;border-radius:12px}}
  .header{{background:linear-gradient(135deg,#1f6feb,#58a6ff);color:white;padding:25px;border-radius:8px;margin-bottom:25px}}
  .header h1{{margin:0;font-size:26px}}
  .ml-box{{background:linear-gradient(135deg,#8957e5,#bc8cff);color:white;padding:20px;border-radius:8px;margin:20px 0}}
  .taint-box{{background:linear-gradient(135deg,#e67e22,#f39c12);color:white;padding:20px;border-radius:8px;margin:20px 0}}
  .stats{{display:flex;gap:15px;margin:20px 0;flex-wrap:wrap}}
  .stat{{background:#21262d;padding:18px;border-radius:8px;flex:1;min-width:150px;text-align:center;border:1px solid #30363d}}
  .stat h3{{margin:0 0 8px 0;font-size:12px;color:#8b949e;text-transform:uppercase}}
  .stat h2{{margin:0;font-size:28px}}
  .vuln{{margin:16px 0;padding:18px;border-left:4px solid;border-radius:4px;background:#21262d}}
  .critical{{border-color:#ff6b6b;background:rgba(255,107,107,.08)}}
  .high{{border-color:#ffa500;background:rgba(255,165,0,.08)}}
  .medium{{border-color:#ffd93d;background:rgba(255,217,61,.08)}}
  .low{{border-color:#6bcf7f;background:rgba(107,207,127,.08)}}
  .taint-finding{{border-left:4px solid #ff9f43;background:rgba(255,159,67,.1)}}
  .vuln h3{{margin:0 0 8px;color:#58a6ff}}
  .detail{{margin:6px 0;padding:6px 10px;background:#161b22;border-radius:4px;font-family:Consolas,monospace;font-size:13px}}
  .cwe{{color:#a29bfe;font-size:12px}}
  .fix{{color:#55efc4;font-size:12px}}
  .badge{{display:inline-block;padding:2px 8px;border-radius:12px;font-size:11px;font-weight:bold;margin-right:6px}}
  .badge-taint{{background:#ff9f43;color:#000}}
  .badge-pattern{{background:#58a6ff;color:#000}}
  h2.section{{color:#58a6ff;margin-top:30px;border-bottom:1px solid #30363d;padding-bottom:8px}}
</style>
</head>
<body><div class="container">
<div class="header">
  <h1>🔒 Security Analysis Report — Enhanced v4.0</h1>
  <p style="margin:8px 0 0 0;opacity:.9">Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
  <p style="margin:4px 0 0 0">📁 {os.path.basename(self.current_results.get('file','Unknown'))} &nbsp;|&nbsp; 💻 {self.current_results.get('language','?')}</p>
</div>
"""
        if ml:
            html += f"""<div class="ml-box">
  <h2 style="margin:0 0 12px">🤖 ML Prediction (RF + Gradient Boosting Ensemble)</h2>
  <span>Risk: <strong>{ml.get('risk_level','?')}</strong> &nbsp;|&nbsp; 
  Probability: <strong>{ml.get('probability',0):.1%}</strong> &nbsp;|&nbsp;
  {'⚠️ RISK DETECTED' if ml.get('prediction') else '✅ LOW RISK'}</span>
</div>
"""
        if taint_vulns:
            html += f"""<div class="taint-box">
  <h2 style="margin:0 0 12px">🔗 Taint Analysis — {len(taint_vulns)} Data Flow Finding(s)</h2>
  <p style="margin:0">User-controlled input was traced flowing into dangerous sinks.</p>
</div>
"""
        html += f"""<div class="stats">
  <div class="stat"><h3>Total</h3><h2>{self.current_results.get('total',0)}</h2></div>
  <div class="stat"><h3>Critical</h3><h2 style="color:#ff6b6b">{crit_c}</h2></div>
  <div class="stat"><h3>High</h3><h2 style="color:#ffa500">{high_c}</h2></div>
  <div class="stat"><h3>Medium</h3><h2 style="color:#ffd93d">{med_c}</h2></div>
  <div class="stat"><h3>Low</h3><h2 style="color:#6bcf7f">{low_c}</h2></div>
  <div class="stat"><h3>Taint Findings</h3><h2 style="color:#ff9f43">{len(taint_vulns)}</h2></div>
</div>
"""
        # Taint section
        if taint_vulns:
            html += "<h2 class='section'>🔗 Taint Analysis Findings</h2>"
            for i, v in enumerate(taint_vulns, 1):
                html += f"""<div class="vuln taint-finding">
  <h3>{i}. {v['type']} <span class="badge badge-taint">TAINT</span></h3>
  <div class="detail">📡 Source (line {v.get('source_line','?')}): <code>{v.get('source_code','')[:120]}</code></div>
  <div class="detail">💀 Sink (line {v.get('sink_line','?')}): <code>{v.get('sink_code','')[:120]}</code></div>
  <div class="detail">🗣️ {v.get('explanation','')}</div>
  {'<div class="detail cwe">🏷️  ' + v.get('cwe_id','') + ' – ' + v.get('cwe_name','') + '</div>' if v.get('cwe_id') and v['cwe_id'] != 'N/A' else ''}
  {'<div class="detail fix">🔧 ' + v.get('remediation','') + '</div>' if v.get('remediation') else ''}
</div>"""

        # Pattern findings by severity
        for sev in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
            vulns = [v for v in summ.get(sev, []) if not v.get('taint_flow')]
            if vulns:
                icons = {'CRITICAL':'⛔','HIGH':'🔴','MEDIUM':'🟡','LOW':'🟢'}
                html += f"<h2 class='section'>{icons[sev]} {sev} ({len(vulns)})</h2>"
                for i, v in enumerate(vulns, 1):
                    html += f"""<div class="vuln {sev.lower()}">
  <h3>{i}. {v['type']} <span class="badge badge-pattern">{v.get('source','Pattern')}</span></h3>
  <div class="detail">📝 {v['description']}</div>
  <div class="detail">📍 Line {v['line']}: <code>{v['code'][:200]}</code></div>
  {'<div class="detail cwe">🏷️  ' + v.get('cwe_id','') + ' – ' + v.get('cwe_name','') + '</div>' if v.get('cwe_id') and v['cwe_id'] != 'N/A' else ''}
  {'<div class="detail fix">🔧 ' + v.get('remediation','') + '</div>' if v.get('remediation') else ''}
</div>"""

        html += "</div></body></html>"
        with open(fp, 'w', encoding='utf-8') as f:
            f.write(html)

    def __del__(self):
        if hasattr(self, 'conn'):
            self.conn.close()


# ─────────────────────────────────────────────────────────────────────────────
def main():
    root = tk.Tk()
    app  = EnhancedBugPredictionGUI(root)
    root.after(500, app._refresh_history)
    root.after(500, app._update_dashboard)
    root.mainloop()

if __name__ == "__main__":
    main()
