# Enhanced Security Bug Prediction System v5.0

A desktop application for ML-powered static security analysis of source code.  
Supports Python, JavaScript, Java, C/C++, PHP, Go, and Rust.

---

## What's New in v5.0

| | v4.0 (old) | v5.0 (this release) |
|---|---|---|
| Training dataset | `security_dataset.csv` — 4,387 rows | `final_security_dataset.csv` — **331,329 rows** |
| Features | 22 hand-crafted regex features | **42 pre-engineered features** (structural + security flags + language one-hots) |
| Model format | Separate `rf_model.pkl`, `gb_model.pkl`, `scaler.pkl` | Self-contained **sklearn Pipeline** objects (scaler embedded) |
| Languages | 7 | 8 (added Rust) |

---

## Project Structure

```
final_project/
├── enhanced_main.py          # Main GUI application
├── train_model.py            # ML training pipeline (run once)
├── final_security_dataset.csv# Full training dataset (330k+ samples)
├── build_final_dataset.py    # Dataset generation script
├── ml_pipeline_starter.py    # Pipeline reference implementation
├── requirements.txt
├── models/                   # Populated after running train_model.py
│   ├── randomforest_pipeline.pkl
│   ├── gradientboosting_pipeline.pkl
│   └── training_summary_v2.json
├── test_samples/
│   ├── vulnerable_python.py
│   └── vulnerable_javascript.js
└── patch_instructions.py
```

---

## Quick Start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

### 2. Train the models (run once)

```bash
python train_model.py
```

This reads `final_security_dataset.csv`, trains RF + GB pipelines, and saves:
- `models/randomforest_pipeline.pkl`
- `models/gradientboosting_pipeline.pkl`
- `models/training_summary_v2.json`

Training takes ~2–5 minutes depending on hardware.

### 3. Launch the application

```bash
python enhanced_main.py
```

The app loads the trained pipeline files automatically on startup.  
If pipeline files are missing it falls back to a lightweight synthetic model with a warning.

---

## ML Pipeline Details

### Features (42 total)

| Category | Features |
|---|---|
| Code size | `loc`, `sloc`, `code_length`, `avg_line_length` |
| Readability | `comment_ratio`, `lexical_diversity` |
| Tokens | `num_tokens`, `num_unique_tokens` |
| Structure | `num_functions`, `num_classes`, `num_imports`, `nesting_depth` |
| Complexity | `num_conditionals`, `num_loops`, `num_try_catch`, `num_assertions`, `cyclomatic_proxy` |
| Security flags | `has_user_input`, `has_db_query`, `has_exec_call`, `has_crypto`, `has_file_ops`, `has_network_ops`, `has_dangerous_func`, `has_hardcoded_secret`, `has_string_concat_query`, `has_output_write`, `has_rand`, `has_thread_ops`, `has_reflection`, `taint_flow_proxy` |
| Encodings | `cwe_numeric`, `severity_numeric`, `vuln_type_encoded` |
| Language | `lang_python`, `lang_java`, `lang_javascript`, `lang_cpp`, `lang_c`, `lang_php`, `lang_go`, `lang_rust` |

### Models

- **Random Forest** — 200 trees, max depth 15, balanced class weights
- **Gradient Boosting** — 150 estimators, learning rate 0.1, max depth 5
- **Ensemble** — 60% RF + 40% GB weighted average
- **Scaler** — `StandardScaler` embedded inside each sklearn `Pipeline`

### Training split

| Split | Fraction | Purpose |
|---|---|---|
| Train | 70% | Model fitting |
| Validation | 10% | Hyperparameter reference |
| Test | 20% | Final evaluation |

---

## Requirements

```
scikit-learn>=1.3.0
numpy>=1.21.0
pandas>=1.3.0
joblib>=1.1.0
```

Optional: install `semgrep` for additional static analysis rules.
