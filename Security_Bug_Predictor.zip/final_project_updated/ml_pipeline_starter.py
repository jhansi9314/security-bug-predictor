"""
ml_pipeline_starter.py
=======================
Ready-to-run ML pipeline for the final_security_dataset.csv.
Covers: loading, preprocessing, training, evaluation, and saving.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, accuracy_score, f1_score
)
from sklearn.pipeline import Pipeline
from sklearn.feature_selection import SelectFromModel
import pickle, json, os

# ──────────────────────────────────────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────────────────────────────────────

DATASET_PATH = "final_security_dataset.csv"
MODELS_DIR   = "models/"
TARGET       = "is_vulnerable"

# All numeric ML-ready feature columns (no 'code', no string categoricals)
FEATURE_COLS = [
    "loc", "sloc", "code_length", "avg_line_length", "comment_ratio",
    "num_tokens", "num_unique_tokens", "lexical_diversity",
    "num_functions", "num_classes", "num_imports", "nesting_depth",
    "num_conditionals", "num_loops", "num_try_catch", "num_assertions",
    "cyclomatic_proxy",
    "has_user_input", "has_db_query", "has_exec_call", "has_crypto",
    "has_file_ops", "has_network_ops", "has_dangerous_func",
    "has_hardcoded_secret", "has_string_concat_query", "has_output_write",
    "has_rand", "has_thread_ops", "has_reflection", "taint_flow_proxy",
    "cwe_numeric", "severity_numeric", "vuln_type_encoded",
    "lang_python", "lang_java", "lang_javascript", "lang_cpp",
    "lang_c", "lang_php", "lang_go", "lang_rust",
]

# ──────────────────────────────────────────────────────────────────────────────
# 1. LOAD & VALIDATE
# ──────────────────────────────────────────────────────────────────────────────

def load_data(path: str) -> tuple:
    print(f"Loading {path}...")
    df = pd.read_csv(path)
    print(f"  Shape : {df.shape}")
    print(f"  Label : {df[TARGET].value_counts().to_dict()}")

    # Keep only columns that exist in this dataset
    feature_cols = [c for c in FEATURE_COLS if c in df.columns]
    missing = set(FEATURE_COLS) - set(feature_cols)
    if missing:
        print(f"  ⚠ Missing feature cols (will skip): {missing}")

    X = df[feature_cols].fillna(0)
    y = df[TARGET]
    return X, y, df, feature_cols


# ──────────────────────────────────────────────────────────────────────────────
# 2. SPLIT
# ──────────────────────────────────────────────────────────────────────────────

def split(X, y, test_size=0.2, val_size=0.1, random_state=42):
    # First split off test
    X_temp, X_test, y_temp, y_test = train_test_split(
        X, y, test_size=test_size, stratify=y, random_state=random_state)
    # Then split val from train
    val_ratio = val_size / (1 - test_size)
    X_train, X_val, y_train, y_val = train_test_split(
        X_temp, y_temp, test_size=val_ratio, stratify=y_temp, random_state=random_state)
    print(f"  Train: {len(X_train):,}  |  Val: {len(X_val):,}  |  Test: {len(X_test):,}")
    return X_train, X_val, X_test, y_train, y_val, y_test


# ──────────────────────────────────────────────────────────────────────────────
# 3. BUILD PIPELINES
# ──────────────────────────────────────────────────────────────────────────────

def build_pipelines():
    rf = Pipeline([
        ("scaler", StandardScaler()),
        ("model",  RandomForestClassifier(
            n_estimators=200, max_depth=15, min_samples_leaf=2,
            class_weight="balanced", n_jobs=-1, random_state=42))
    ])
    gb = Pipeline([
        ("scaler", StandardScaler()),
        ("model",  GradientBoostingClassifier(
            n_estimators=150, learning_rate=0.1, max_depth=5,
            subsample=0.8, random_state=42))
    ])
    return {"RandomForest": rf, "GradientBoosting": gb}


# ──────────────────────────────────────────────────────────────────────────────
# 4. TRAIN & EVALUATE
# ──────────────────────────────────────────────────────────────────────────────

def train_evaluate(pipelines, X_train, X_val, X_test, y_train, y_val, y_test, feature_cols):
    results = {}
    trained = {}

    for name, pipe in pipelines.items():
        print(f"\n  Training {name}...")
        pipe.fit(X_train, y_train)

        # Val metrics
        y_val_pred  = pipe.predict(X_val)
        y_val_proba = pipe.predict_proba(X_val)[:, 1]
        val_acc  = accuracy_score(y_val, y_val_pred)
        val_f1   = f1_score(y_val, y_val_pred)
        val_auc  = roc_auc_score(y_val, y_val_proba)

        # Test metrics
        y_test_pred  = pipe.predict(X_test)
        y_test_proba = pipe.predict_proba(X_test)[:, 1]
        test_acc  = accuracy_score(y_test, y_test_pred)
        test_f1   = f1_score(y_test, y_test_pred)
        test_auc  = roc_auc_score(y_test, y_test_proba)

        print(f"    Val  → Acc: {val_acc:.4f}  F1: {val_f1:.4f}  AUC: {val_auc:.4f}")
        print(f"    Test → Acc: {test_acc:.4f}  F1: {test_f1:.4f}  AUC: {test_auc:.4f}")
        print(f"\n    Classification Report (Test):")
        print(classification_report(y_test, y_test_pred,
                                    target_names=["Safe", "Vulnerable"]))

        # Feature importance (for tree-based models)
        if hasattr(pipe.named_steps["model"], "feature_importances_"):
            importances = pipe.named_steps["model"].feature_importances_
            top_features = sorted(
                zip(feature_cols, importances),
                key=lambda x: x[1], reverse=True
            )[:10]
            print(f"    Top 10 features:")
            for feat, imp in top_features:
                print(f"      {feat:<35} {imp:.4f}")

        results[name] = {
            "val_accuracy": round(val_acc, 4),
            "val_f1": round(val_f1, 4),
            "val_roc_auc": round(val_auc, 4),
            "test_accuracy": round(test_acc, 4),
            "test_f1": round(test_f1, 4),
            "test_roc_auc": round(test_auc, 4),
        }
        trained[name] = pipe

    # ── Cross-validation on full train set ──
    print("\n  5-Fold CV on best model...")
    best_name = max(results, key=lambda n: results[n]["val_f1"])
    best_pipe = trained[best_name]
    X_all = pd.concat([X_train, X_val])
    y_all = pd.concat([y_train, y_val])
    cv_scores = cross_val_score(
        best_pipe, X_all, y_all,
        cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=42),
        scoring="f1"
    )
    print(f"  CV F1 (mean±std): {cv_scores.mean():.4f} ± {cv_scores.std():.4f}")
    results[best_name]["cv_f1_mean"] = round(cv_scores.mean(), 4)
    results[best_name]["cv_f1_std"]  = round(cv_scores.std(), 4)

    return trained, results


# ──────────────────────────────────────────────────────────────────────────────
# 5. SAVE MODELS
# ──────────────────────────────────────────────────────────────────────────────

def save_models(trained: dict, results: dict, feature_cols: list):
    os.makedirs(MODELS_DIR, exist_ok=True)
    for name, pipe in trained.items():
        fname = f"{MODELS_DIR}{name.lower().replace(' ','_')}_pipeline.pkl"
        with open(fname, "wb") as f:
            pickle.dump(pipe, f)
        print(f"  Saved: {fname}")

    summary = {
        "feature_columns": feature_cols,
        "target": TARGET,
        "models": results,
    }
    with open(f"{MODELS_DIR}training_summary_v2.json", "w") as f:
        json.dump(summary, f, indent=2)
    print(f"  Saved: {MODELS_DIR}training_summary_v2.json")


# ──────────────────────────────────────────────────────────────────────────────
# 6. INFERENCE HELPER
# ──────────────────────────────────────────────────────────────────────────────

def predict_snippet(code: str, language: str, model_path: str) -> dict:
    """
    Predict vulnerability for a single code snippet.
    Usage:
        result = predict_snippet(my_code, 'python', 'models/randomforest_pipeline.pkl')
    """
    import sys, os
    sys.path.insert(0, os.path.dirname(__file__))
    from build_final_dataset import compute_features, add_label_encodings

    with open(model_path, "rb") as f:
        pipe = pickle.load(f)

    feats = compute_features(code, language)
    row = pd.DataFrame([feats])
    # Fill any missing columns with 0
    with open("models/training_summary_v2.json") as f:
        summary = json.load(f)
    for col in summary["feature_columns"]:
        if col not in row.columns:
            row[col] = 0
    row = row[summary["feature_columns"]].fillna(0)

    pred  = pipe.predict(row)[0]
    proba = pipe.predict_proba(row)[0]
    return {
        "is_vulnerable": int(pred),
        "confidence":    round(float(proba[pred]), 4),
        "prob_safe":     round(float(proba[0]), 4),
        "prob_vuln":     round(float(proba[1]), 4),
    }


# ──────────────────────────────────────────────────────────────────────────────
# 7. MAIN
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("\n" + "="*60)
    print("  ML Pipeline — Security Vulnerability Detector")
    print("="*60)

    X, y, df, feature_cols = load_data(DATASET_PATH)
    print(f"  Using {len(feature_cols)} feature columns")

    print("\n[1] Splitting...")
    X_train, X_val, X_test, y_train, y_val, y_test = split(X, y)

    print("\n[2] Building pipelines...")
    pipelines = build_pipelines()

    print("\n[3] Training & evaluating...")
    trained, results = train_evaluate(
        pipelines, X_train, X_val, X_test, y_train, y_val, y_test, feature_cols)

    print("\n[4] Saving models...")
    save_models(trained, results, feature_cols)

    print("\n✅ Pipeline complete!")
    print("="*60)
