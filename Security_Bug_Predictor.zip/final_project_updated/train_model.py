"""
train_model.py  —  ML Training Pipeline v5.0
=============================================
Trains RF + GB sklearn Pipelines on final_security_dataset.csv
(330 k+ samples, 42 pre-engineered features, 8 languages).

Run once to produce:
  models/randomforest_pipeline.pkl
  models/gradientboosting_pipeline.pkl
  models/training_summary_v2.json

The saved pipelines are self-contained (scaler embedded).
enhanced_main.py loads them via MLSecurityPredictor.load_pretrained_models().
"""

import pandas as pd
import numpy as np
import pickle
import json
import os
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score,
    f1_score, roc_auc_score, confusion_matrix, classification_report,
)

os.makedirs("models", exist_ok=True)

# ──────────────────────────────────────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────────────────────────────────────

DATASET_PATH = "final_security_dataset.csv"
TARGET       = "is_vulnerable"

FEATURE_COLS = [
    "loc", "sloc", "code_length", "avg_line_length", "comment_ratio",
    "num_tokens", "num_unique_tokens", "lexical_diversity",
    "num_functions", "num_classes", "num_imports", "nesting_depth",
    "num_conditionals", "num_loops", "num_try_catch", "num_assertions",
    "cyclomatic_proxy",
    "has_user_input", "has_db_query", "has_exec_call", "has_crypto",
    "has_file_ops", "has_network_ops", "has_dangerous_func",
    "has_hardcoded_secret", "has_string_concat_query", "has_output_write",
    "has_rand", "has_thread_ops", "has_reflection", "taint_flow_proxy",
    "cwe_numeric", "severity_numeric", "vuln_type_encoded",
    "lang_python", "lang_java", "lang_javascript", "lang_cpp",
    "lang_c", "lang_php", "lang_go", "lang_rust",
]

# ──────────────────────────────────────────────────────────────────────────────
# STEP 1 — LOAD DATASET
# ──────────────────────────────────────────────────────────────────────────────

print("=" * 60)
print("STEP 1: Loading Dataset")
print("=" * 60)

df = pd.read_csv(DATASET_PATH)
df = df.dropna(subset=[TARGET])

print(f"Total samples       : {len(df):,}")
print(f"Vulnerable  (1)     : {df[TARGET].sum():,}")
print(f"Safe        (0)     : {(df[TARGET] == 0).sum():,}")
print(f"Languages           : {sorted(df['language'].unique().tolist())}")
print(f"Vulnerability types : {df['vulnerability_type'].nunique()}")

feature_cols = [c for c in FEATURE_COLS if c in df.columns]
missing_cols  = set(FEATURE_COLS) - set(feature_cols)
if missing_cols:
    print(f"WARNING: Missing columns (skipped): {missing_cols}")

X = df[feature_cols].fillna(0)
y = df[TARGET]

print(f"\nFeature matrix : {X.shape}")

# ──────────────────────────────────────────────────────────────────────────────
# STEP 2 — TRAIN / VAL / TEST SPLIT
# ──────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("STEP 2: Train / Val / Test Split  (70 / 10 / 20)")
print("=" * 60)

X_temp, X_test, y_temp, y_test = train_test_split(
    X, y, test_size=0.20, stratify=y, random_state=42
)
X_train, X_val, y_train, y_val = train_test_split(
    X_temp, y_temp, test_size=0.125, stratify=y_temp, random_state=42
)

print(f"  Train : {len(X_train):,}")
print(f"  Val   : {len(X_val):,}")
print(f"  Test  : {len(X_test):,}")

# ──────────────────────────────────────────────────────────────────────────────
# STEP 3 — BUILD SKLEARN PIPELINES
# ──────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("STEP 3: Building sklearn Pipelines  (scaler embedded)")
print("=" * 60)

rf_pipeline = Pipeline([
    ("scaler", StandardScaler()),
    ("model",  RandomForestClassifier(
        n_estimators=200, max_depth=15, min_samples_leaf=2,
        class_weight="balanced", n_jobs=-1, random_state=42,
    )),
])

gb_pipeline = Pipeline([
    ("scaler", StandardScaler()),
    ("model",  GradientBoostingClassifier(
        n_estimators=150, learning_rate=0.1, max_depth=5,
        subsample=0.8, random_state=42,
    )),
])

pipelines = {"RandomForest": rf_pipeline, "GradientBoosting": gb_pipeline}

# ──────────────────────────────────────────────────────────────────────────────
# STEP 4 — TRAIN & EVALUATE
# ──────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("STEP 4: Training & Evaluating")
print("=" * 60)

results = {}
trained = {}

for name, pipe in pipelines.items():
    print(f"\n  [{name}]  Training on {len(X_train):,} samples...")
    pipe.fit(X_train, y_train)

    for split_name, Xs, ys in [("Val", X_val, y_val), ("Test", X_test, y_test)]:
        y_pred  = pipe.predict(Xs)
        y_proba = pipe.predict_proba(Xs)[:, 1]
        acc  = accuracy_score(ys, y_pred)
        prec = precision_score(ys, y_pred, zero_division=0)
        rec  = recall_score(ys, y_pred, zero_division=0)
        f1   = f1_score(ys, y_pred, zero_division=0)
        auc  = roc_auc_score(ys, y_proba)
        cm   = confusion_matrix(ys, y_pred)
        print(f"    {split_name:5s} -> Acc: {acc:.4f}  Prec: {prec:.4f}  "
              f"Rec: {rec:.4f}  F1: {f1:.4f}  AUC: {auc:.4f}")
        print(f"           CM  TN={cm[0,0]}  FP={cm[0,1]}  FN={cm[1,0]}  TP={cm[1,1]}")
        if split_name == "Test":
            results[name] = dict(
                test_accuracy=round(acc, 4),  test_precision=round(prec, 4),
                test_recall=round(rec, 4),    test_f1=round(f1, 4),
                test_roc_auc=round(auc, 4),
            )

    model = pipe.named_steps["model"]
    if hasattr(model, "feature_importances_"):
        top = sorted(
            zip(feature_cols, model.feature_importances_),
            key=lambda x: x[1], reverse=True,
        )[:10]
        print("    Top-10 features:")
        for feat, imp in top:
            print(f"      {feat:<38} {imp:.4f}")

    trained[name] = pipe

# Ensemble evaluation
print("\n  [Ensemble  60% RF + 40% GB]")
rf_prob  = trained["RandomForest"].predict_proba(X_test)[:, 1]
gb_prob  = trained["GradientBoosting"].predict_proba(X_test)[:, 1]
ens_prob = rf_prob * 0.6 + gb_prob * 0.4
ens_pred = (ens_prob >= 0.5).astype(int)
ens_acc  = accuracy_score(y_test, ens_pred)
ens_f1   = f1_score(y_test, ens_pred, zero_division=0)
ens_auc  = roc_auc_score(y_test, ens_prob)
ens_cm   = confusion_matrix(y_test, ens_pred)
print(f"    Test  -> Acc: {ens_acc:.4f}  F1: {ens_f1:.4f}  AUC: {ens_auc:.4f}")
print(f"           CM  TN={ens_cm[0,0]}  FP={ens_cm[0,1]}  FN={ens_cm[1,0]}  TP={ens_cm[1,1]}")
print("\n  Classification Report (Ensemble / Test):")
print(classification_report(y_test, ens_pred, target_names=["Safe", "Vulnerable"]))

# Cross-validation
print("  5-Fold CV on RandomForest (train + val combined)...")
X_all = pd.concat([X_train, X_val])
y_all = pd.concat([y_train, y_val])
cv_scores = cross_val_score(
    trained["RandomForest"], X_all, y_all,
    cv=StratifiedKFold(n_splits=5, shuffle=True, random_state=42),
    scoring="f1",
)
print(f"  CV F1 per fold : {cv_scores.round(4)}")
print(f"  CV F1 mean+std : {cv_scores.mean():.4f} +/- {cv_scores.std():.4f}")
results["RandomForest"]["cv_f1_mean"] = round(cv_scores.mean(), 4)
results["RandomForest"]["cv_f1_std"]  = round(cv_scores.std(),  4)

# ──────────────────────────────────────────────────────────────────────────────
# STEP 5 — SAVE PIPELINES
# ──────────────────────────────────────────────────────────────────────────────

print("\n" + "=" * 60)
print("STEP 5: Saving Pipelines & Summary")
print("=" * 60)

for name, pipe in trained.items():
    fname = f"models/{name.lower()}_pipeline.pkl"
    with open(fname, "wb") as f:
        pickle.dump(pipe, f)
    print(f"  Saved: {fname}")

summary = {
    "dataset":             DATASET_PATH,
    "total_samples":       len(df),
    "vulnerable":          int(df[TARGET].sum()),
    "safe":                int((df[TARGET] == 0).sum()),
    "languages":           sorted(df["language"].unique().tolist()),
    "vulnerability_types": df["vulnerability_type"].unique().tolist(),
    "feature_columns":     feature_cols,
    "target":              TARGET,
    "ensemble_accuracy":   round(ens_acc, 4),
    "ensemble_f1":         round(ens_f1, 4),
    "ensemble_roc_auc":    round(ens_auc, 4),
    "cv_f1_mean":          round(cv_scores.mean(), 4),
    "models":              results,
}

with open("models/training_summary_v2.json", "w") as f:
    json.dump(summary, f, indent=2)
print("  Saved: models/training_summary_v2.json")

print("\n" + "=" * 60)
print("  TRAINING COMPLETE")
print(f"  Ensemble Accuracy : {ens_acc*100:.2f}%")
print(f"  Ensemble F1       : {ens_f1:.4f}")
print(f"  Ensemble ROC-AUC  : {ens_auc:.4f}")
print("=" * 60)
