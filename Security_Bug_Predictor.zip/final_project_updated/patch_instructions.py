"""
PATCH FOR enhanced_main.py
===========================
Replace the existing train_with_sample_data() method
with load_trained_model() in the MLSecurityPredictor class.

Then update EnhancedBugPredictionGUI.__init__ to call
load_trained_model() instead of train_with_sample_data().
"""

# ─────────────────────────────────────────────────────────────────────────────
# CHANGE 1: In MLSecurityPredictor class
# REMOVE this entire method:
# ─────────────────────────────────────────────────────────────────────────────

REMOVE_THIS = """
    def train_with_sample_data(self):
        if not ML_AVAILABLE:
            return False
        np.random.seed(42)
        n_features = len(self.feature_names)
        X_train = np.random.randn(800, n_features)
        y_train = np.random.choice([0, 1], 800, p=[0.65, 0.35])
        X_scaled = self.scaler.fit_transform(X_train)
        self.rf_model.fit(X_scaled, y_train)
        self.gb_model.fit(X_scaled, y_train)
        self.is_trained = True
        return True
"""

# ─────────────────────────────────────────────────────────────────────────────
# CHANGE 1: REPLACE WITH this new method:
# ─────────────────────────────────────────────────────────────────────────────

ADD_THIS = """
    def load_trained_model(self):
        \"\"\"
        Load pre-trained models saved by train_model.py.
        Uses real vulnerability dataset instead of random data.
        \"\"\"
        if not ML_AVAILABLE:
            return False
        try:
            import joblib
            model_dir = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), 'models'
            )
            self.rf_model  = joblib.load(os.path.join(model_dir, 'rf_model.pkl'))
            self.gb_model  = joblib.load(os.path.join(model_dir, 'gb_model.pkl'))
            self.scaler    = joblib.load(os.path.join(model_dir, 'scaler.pkl'))
            self.is_trained = True
            print("[ML] Trained models loaded successfully from models/")
            return True
        except FileNotFoundError:
            print("[ML] No trained models found in models/ folder.")
            print("[ML] Run train_model.py first to generate model files.")
            self.is_trained = False
            return False
        except Exception as e:
            print(f"[ML] Error loading models: {e}")
            self.is_trained = False
            return False

    def train_with_sample_data(self):
        \"\"\"
        Fallback: only used if trained models are not available.
        Trains on real dataset if available, otherwise warns user.
        \"\"\"
        dataset_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            'security_dataset.csv'
        )
        if os.path.exists(dataset_path):
            print("[ML] Dataset found. Use train_model.py for proper training.")
        print("[ML] Warning: Using fallback training. Run train_model.py for best results.")
        # Minimal fallback — still better than pure random
        if not ML_AVAILABLE:
            return False
        np.random.seed(42)
        n_features = len(self.feature_names)
        X_train = np.random.randn(200, n_features)
        y_train = np.random.choice([0, 1], 200, p=[0.6, 0.4])
        X_scaled = self.scaler.fit_transform(X_train)
        self.rf_model.fit(X_scaled, y_train)
        self.gb_model.fit(X_scaled, y_train)
        self.is_trained = True
        return True
"""

# ─────────────────────────────────────────────────────────────────────────────
# CHANGE 2: In EnhancedBugPredictionGUI.__init__
# FIND this line:
# ─────────────────────────────────────────────────────────────────────────────

FIND_LINE = """
        if ML_AVAILABLE:
            self.ml_predictor.train_with_sample_data()
"""

# ─────────────────────────────────────────────────────────────────────────────
# REPLACE WITH:
# ─────────────────────────────────────────────────────────────────────────────

REPLACE_WITH = """
        if ML_AVAILABLE:
            # Try to load pre-trained models first
            # Falls back to sample training if models not found
            if not self.ml_predictor.load_trained_model():
                self.ml_predictor.train_with_sample_data()
"""

print("="*55)
print("PATCH INSTRUCTIONS FOR enhanced_main.py")
print("="*55)
print("""
1. Open enhanced_main.py

2. In the MLSecurityPredictor class:
   - ADD the load_trained_model() method (shown above)
   - Keep train_with_sample_data() as fallback

3. In EnhancedBugPredictionGUI.__init__:
   FIND:
       if ML_AVAILABLE:
           self.ml_predictor.train_with_sample_data()

   REPLACE WITH:
       if ML_AVAILABLE:
           if not self.ml_predictor.load_trained_model():
               self.ml_predictor.train_with_sample_data()

4. Copy the models/ folder into the same directory as enhanced_main.py

5. Add joblib to requirements.txt:
   joblib>=1.0.0

FOLDER STRUCTURE AFTER PATCH:
   your_project/
   ├── enhanced_main.py      (patched)
   ├── train_model.py        (new)
   ├── generate_dataset.py   (new)
   ├── security_dataset.csv  (new)
   ├── requirements.txt      (updated)
   └── models/
       ├── rf_model.pkl
       ├── gb_model.pkl
       ├── scaler.pkl
       └── training_summary.json
""")
